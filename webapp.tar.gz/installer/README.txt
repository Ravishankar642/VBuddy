VBuddy
======

1. Start VBuddy from the Start menu (or VBuddy.vbs). It opens the VBuddy window and keeps
   running as an icon in the notification area (look under the ^ arrow; drag it to the taskbar
   if you like). Double-click the icon to open the window again.

2. The VBuddy window shows the address to open on your phone or tablet (same Wi-Fi, or scan the
   QR code) and the pairing code you type on the phone's Cockpit tab to control the aircraft.
   To use VBuddy away from home, switch on "Cloud relay" in the window and open the phone link
   it shows. Right-click the icon for the log, settings, Restart and Exit.
   "VBuddy with a window" (VBuddy.cmd) shows the log in a console window, for troubleshooting.

3. Chat and VATSIM connect/disconnect from the app need the "VBuddy Link" plugin in vPilot
   (the installer offers it). Restart vPilot after installing it.

4. Settings (relay for use away from home, port, notifications): Start menu > "VBuddy settings".

Phone can't connect? Check both are on the same Wi-Fi, that the Windows network is set to
"Private", and that the installer's firewall option was ticked (or allow TCP port 4789).

Files and licenses: LICENSE.txt, THIRD_PARTY_NOTICES.md. What's new: CHANGELOG.md.
