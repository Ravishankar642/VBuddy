# Changelog

## 1.0.0
First release.

- **Bridge** for MSFS 2024 (SimConnect) with a built-in test flight; serves the web app on your network. Runs as a notification-area (tray) icon with Open, Copy address, Pairing code, Settings, Log, Start with Windows, Restart and Exit.
- **Flight** dashboard, **Map** with live VATSIM traffic and ATC boundary alerts, **Landings** log with touchdown rate, G, flare and bounces.
- **Cockpit**: Fenix A320 FCU and EFIS with split-touch knobs, lights card for every aircraft. Other Airbus: lights only. Cockpit controls are Airbus-only in this release.
- **Comms**: Zulu clock, VATSIM status, COM1/COM2 tuning and listen toggles, transponder, chat (radio, private, broadcast, SELCAL), unread badge and chime, via the **VBuddy Link** vPilot plugin. "Listen on this device" opens VATSIM Listen.
- **Pairing**: viewing is open on your network; controlling needs a code from the bridge PC.
- **VBuddy window** on the bridge PC (opens from the tray icon): simulator and vPilot status, phone address with QR code, pairing code, paired devices, and the cloud relay switch.
- **Away from home**: a shared cloud relay (https, `vbuddy.duckdns.org`) that anyone can switch on in the VBuddy window with no setup: each install makes its own id and key, so many PCs share one relay and nothing secret is built in. Phone link with QR code. Or host your own. Phone notifications for ATC, landings and chat.
- **Flight log** on disk with automatic catch-up after a dropped connection.
- Windows installer (bundles Node.js), portable zip, optional Start-with-Windows and firewall rule.
- Tools: `aircraft:discover` (find an aircraft's controls), `fenix:discover`, `pmdg:dump`.

Known limits: not yet tested end-to-end against a real MSFS 2024, vPilot or relay VM by the author's automated tests; IVAO is not included; PMDG, iniBuilds, iFly and FSLabs cockpit panels are not available yet (the PMDG code is present but switched off).
