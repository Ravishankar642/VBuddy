import { LIGHT_IDS, type ApButton, type ApKnob, type LightId, type PanelState } from "@vbuddy/protocol";
import type { PanelBackend, PanelResult } from "./backend.js";

/** A pretend Boeing for the mock flight and tests. */
export class MockPanel implements PanelBackend {
  private s: PanelState;
  constructor(kind: "fenix" | "boeing" = "boeing") {
    this.s = structuredClone(this.initial);
    this.s.aircraft = kind === "boeing" ? "Mock Boeing 737-800" : "Mock Fenix A320";
    this.s.family = kind === "boeing" ? "boeing" : "airbus";
  }
  private initial: PanelState = {
    aircraft: "Mock Boeing 737-800",
    family: "boeing",
    lights: Object.fromEntries(LIGHT_IDS.map((l) => [l, l === "nav" || l === "panel"])) as PanelState["lights"],
    ap: { master: false, fd: true, athr: true, speed: false, lvlChg: false, hdgSel: false, lnav: false, app: false, altHld: false, vs: false, spd: 250, machMode: false, hdg: 90, alt: 10000, vsFpm: 0, crs: 90 },
    note: null,
  };
  private cbs: Array<() => void> = [];
  /** Controls that should pretend the aircraft ignored them (tests). */
  ignore = new Set<string>();

  state() {
    return this.s;
  }
  onChange(cb: () => void) {
    this.cbs.push(cb);
  }
  private change(fn: (s: PanelState) => void) {
    this.s = structuredClone(this.s);
    fn(this.s);
    for (const cb of this.cbs) cb();
  }
  async setLight(id: LightId, on: boolean): Promise<PanelResult> {
    if (this.ignore.has(id)) return { ok: false, error: `The ${id} light didn't respond.` };
    this.change((s) => (s.lights[id] = on));
    return { ok: true };
  }
  async press(ctl: ApButton): Promise<PanelResult> {
    if (this.ignore.has(ctl)) return { ok: false, error: "The aircraft didn't respond." };
    this.change((s) => {
      const ap = s.ap!;
      const key = ctl === "cmd" ? "master" : ctl;
      (ap as unknown as Record<string, boolean>)[key] = !(ap as unknown as Record<string, boolean>)[key];
    });
    return { ok: true };
  }
  async set(ctl: ApKnob, value: number): Promise<PanelResult> {
    if (this.ignore.has(ctl)) return { ok: false, error: "The aircraft didn't respond." };
    this.change((s) => {
      const ap = s.ap!;
      if (ctl === "spd") ap.spd = value;
      else if (ctl === "hdg") ap.hdg = value;
      else if (ctl === "alt") ap.alt = value;
      else if (ctl === "vs") ap.vsFpm = value;
      else ap.crs = value;
    });
    return { ok: true };
  }
}
