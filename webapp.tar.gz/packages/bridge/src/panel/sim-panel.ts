import { familyOf, LIGHT_IDS, type ApButton, type ApKnob, type LightId, type PanelState, type SimStatus } from "@vbuddy/protocol";
import { DataRequestFlag, EventFlag, SimConnectConstants, SimConnectDataType, SimConnectPeriod, type ConnectionHandle } from "node-simconnect";
import type { PanelBackend, PanelResult } from "./backend.js";

const DEF_PANEL = 70;
const REQ_PANEL = 70;
const EVENT_BASE = 400;
/** A real notification group: SimConnect rejects a group it was never told about. */
const GROUP_PANEL = 62;
const GROUP_PRIORITY_HIGHEST = 1;
const VERIFY_MS = 1200;

/** [simulator variable, unit] in the order they are read. */
const LIGHT_VARS: Record<LightId, string> = {
  nav: "LIGHT NAV ON",
  beacon: "LIGHT BEACON ON",
  strobe: "LIGHT STROBE ON",
  landing: "LIGHT LANDING ON",
  taxi: "LIGHT TAXI ON",
  wing: "LIGHT WING ON",
  logo: "LIGHT LOGO ON",
  recognition: "LIGHT RECOGNITION ON",
  cabin: "LIGHT CABIN ON",
  panel: "LIGHT PANEL ON",
};
const AP_VARS: Array<[string, string]> = [
  ["AUTOPILOT MASTER", "Bool"],
  ["AUTOPILOT FLIGHT DIRECTOR ACTIVE", "Bool"],
  ["AUTOPILOT THROTTLE ARM", "Bool"],
  ["AUTOPILOT AIRSPEED HOLD", "Bool"],
  ["AUTOPILOT FLIGHT LEVEL CHANGE", "Bool"],
  ["AUTOPILOT HEADING LOCK", "Bool"],
  ["AUTOPILOT NAV1 LOCK", "Bool"],
  ["AUTOPILOT APPROACH HOLD", "Bool"],
  ["AUTOPILOT ALTITUDE LOCK", "Bool"],
  ["AUTOPILOT VERTICAL HOLD", "Bool"],
  ["AUTOPILOT MANAGED SPEED IN MACH", "Bool"],
  ["AUTOPILOT AIRSPEED HOLD VAR", "Knots"],
  ["AUTOPILOT MACH HOLD VAR", "Number"],
  ["AUTOPILOT HEADING LOCK DIR", "Degrees"],
  ["AUTOPILOT ALTITUDE LOCK VAR", "Feet"],
  ["AUTOPILOT VERTICAL HOLD VAR", "Feet per minute"],
  ["NAV OBS:1", "Degrees"],
];

const LIGHT_EVENTS: Record<LightId, string> = {
  nav: "TOGGLE_NAV_LIGHTS",
  beacon: "TOGGLE_BEACON_LIGHTS",
  strobe: "STROBES_TOGGLE",
  landing: "LANDING_LIGHTS_TOGGLE",
  taxi: "TOGGLE_TAXI_LIGHTS",
  wing: "TOGGLE_WING_LIGHTS",
  logo: "TOGGLE_LOGO_LIGHTS",
  recognition: "TOGGLE_RECOGNITION_LIGHTS",
  cabin: "TOGGLE_CABIN_LIGHTS",
  panel: "PANEL_LIGHTS_TOGGLE",
};
/** Some add-ons (iniBuilds) only react to their own switch events. Value for "on"; off is 0. Taken from the discovery reports; not all confirmed. */
const INPUT_EVENT_LIGHTS: Partial<Record<LightId, { names: string[]; on: number }>> = {
  nav: { names: ["AIRLINER_LIGHTS_EXT_NAV"], on: 1 },
  beacon: { names: ["AIRLINER_LIGHTS_EXT_BEACON"], on: 1 },
  strobe: { names: ["AIRLINER_LIGHTS_EXT_STROBE"], on: 2 },
  landing: { names: ["AIRLINER_LIGHTS_EXT_LANDING"], on: 1 },
  taxi: { names: ["AIRLINER_LIGHTS_EXT_NOSE"], on: 1 },
  wing: { names: ["AIRLINER_LIGHTS_EXT_WING"], on: 1 },
};
const LABELS: Record<LightId, string> = {
  nav: "Navigation",
  beacon: "Beacon",
  strobe: "Strobe",
  landing: "Landing",
  taxi: "Taxi",
  wing: "Wing",
  logo: "Logo",
  recognition: "Recognition",
  cabin: "Cabin",
  panel: "Panel",
};

const BUTTON_EVENTS: Record<ApButton, { event: string; flag: keyof NonNullable<PanelState["ap"]> }> = {
  cmd: { event: "AP_MASTER", flag: "master" },
  fd: { event: "TOGGLE_FLIGHT_DIRECTOR", flag: "fd" },
  athr: { event: "AUTO_THROTTLE_ARM", flag: "athr" },
  speed: { event: "AP_PANEL_SPEED_HOLD", flag: "speed" },
  lvlChg: { event: "FLIGHT_LEVEL_CHANGE", flag: "lvlChg" },
  hdgSel: { event: "AP_HDG_HOLD", flag: "hdgSel" },
  lnav: { event: "AP_NAV1_HOLD", flag: "lnav" },
  app: { event: "AP_APR_HOLD", flag: "app" },
  altHld: { event: "AP_ALT_HOLD", flag: "altHld" },
  vs: { event: "AP_VS_HOLD", flag: "vs" },
};
const SET_EVENTS: Record<ApKnob, string> = {
  spd: "AP_SPD_VAR_SET",
  hdg: "HEADING_BUG_SET",
  alt: "AP_ALT_VAR_SET_ENGLISH",
  vs: "AP_VS_VAR_SET_ENGLISH",
  crs: "VOR1_SET",
};

interface SimLike {
  onHandle(cb: (h: ConnectionHandle | null) => void): void;
  onStatus(cb: (s: SimStatus) => void): void;
  status(): SimStatus;
  labelSend?(sendId: number, what: string): void;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const angleDiff = (a: number, b: number) => Math.abs((((a - b) % 360) + 540) % 360 - 180);

/**
 * Lights and the standard autopilot, read from and sent to the simulator with its ordinary variables and events.
 * Every command is checked by watching the matching variable change, so the app can say when an add-on aircraft
 * (PMDG, iFly, ...) ignores the standard commands instead of pretending it worked.
 */
export class SimPanel implements PanelBackend {
  private h: ConnectionHandle | null = null;
  private s: PanelState | null = null;
  private cbs: Array<() => void> = [];
  private ids = new Map<string, number>();
  private inputs = new Map<string, bigint>();
  private inputsFor = "";
  private title = "";
  private note: string | null = null;
  private lastJson = "";

  constructor(private sim: SimLike) {
    sim.onHandle((h) => this.attach(h));
    sim.onStatus((st) => {
      if (!st.connected) this.publish(null);
      else if (st.aircraftTitle !== this.title) {
        this.title = st.aircraftTitle;
        this.note = null;
        this.refreshInputEvents();
        if (this.s) this.publish({ ...this.s, aircraft: this.title, family: familyOf(this.title) });
      }
    });
  }

  state() {
    return this.s;
  }
  onChange(cb: () => void) {
    this.cbs.push(cb);
  }
  private publish(s: PanelState | null) {
    const json = JSON.stringify(s);
    if (json === this.lastJson) return;
    this.lastJson = json;
    this.s = s;
    for (const cb of this.cbs) cb();
  }

  private attach(h: ConnectionHandle | null) {
    this.h = h;
    this.ids.clear();
    this.inputs.clear();
    this.inputsFor = "";
    this.publish(null);
    if (!h) return;
    for (const l of LIGHT_IDS) this.sim.labelSend?.(h.addToDataDefinition(DEF_PANEL, LIGHT_VARS[l], "Bool", SimConnectDataType.FLOAT64), LIGHT_VARS[l]);
    for (const [name, unit] of AP_VARS) this.sim.labelSend?.(h.addToDataDefinition(DEF_PANEL, name, unit, SimConnectDataType.FLOAT64), name);
    h.on("simObjectData", (r) => {
      if (r.requestID !== REQ_PANEL || h !== this.h) return;
      const n = [...LIGHT_IDS, ...AP_VARS].map(() => r.data.readFloat64());
      const lights = Object.fromEntries(LIGHT_IDS.map((l, i) => [l, n[i]! > 0])) as PanelState["lights"];
      const a = n.slice(LIGHT_IDS.length);
      const title = this.sim.status().aircraftTitle || this.title;
      this.title = title;
      const mach = a[10]! > 0;
      this.publish({
        aircraft: title,
        family: familyOf(title),
        lights,
        ap: {
          master: a[0]! > 0,
          fd: a[1]! > 0,
          athr: a[2]! > 0,
          speed: a[3]! > 0,
          lvlChg: a[4]! > 0,
          hdgSel: a[5]! > 0,
          lnav: a[6]! > 0,
          app: a[7]! > 0,
          altHld: a[8]! > 0,
          vs: a[9]! > 0,
          machMode: mach,
          spd: mach ? Math.round(a[12]! * 100) / 100 : Math.round(a[11]!),
          hdg: Math.round(a[13]!) % 360,
          alt: Math.round(a[14]!),
          vsFpm: Math.round(a[15]!),
          crs: Math.round(a[16]!) % 360,
        },
        note: this.note,
      });
    });
    h.on("inputEventsList", (r) => {
      for (const d of r.inputEventDescriptors) this.inputs.set(d.name, d.inputEventIdHash);
    });
    this.sim.labelSend?.(h.requestDataOnSimObject(REQ_PANEL, DEF_PANEL, SimConnectConstants.OBJECT_ID_USER, SimConnectPeriod.SIM_FRAME, DataRequestFlag.DATA_REQUEST_FLAG_CHANGED), "lights and autopilot request");
    this.refreshInputEvents();
  }

  /** The simulator's own list of cockpit controls changes with the aircraft. */
  private refreshInputEvents() {
    if (!this.h || this.inputsFor === this.title) return;
    this.inputsFor = this.title;
    this.inputs.clear();
    try {
      this.sim.labelSend?.(this.h.enumerateInputEvents(60), "list of the aircraft's input events");
    } catch {
      /* older simulator: the standard events are all there is */
    }
  }

  private fire(event: string, data: number) {
    const h = this.h;
    if (!h) return false;
    let id = this.ids.get(event);
    if (id === undefined) {
      id = EVENT_BASE + this.ids.size;
      h.mapClientEventToSimEvent(id, event);
      h.addClientEventToNotificationGroup(GROUP_PANEL, id, false);
      h.setNotificationGroupPriority(GROUP_PANEL, GROUP_PRIORITY_HIGHEST);
      this.ids.set(event, id);
    }
    h.transmitClientEvent(SimConnectConstants.OBJECT_ID_USER, id, data, GROUP_PANEL, EventFlag.EVENT_FLAG_DEFAULT);
    return true;
  }

  private async until(test: () => boolean, ms = VERIFY_MS): Promise<boolean> {
    for (let t = 0; t < ms; t += 80) {
      if (test()) return true;
      await sleep(80);
    }
    return test();
  }

  private worked(): PanelResult {
    if (this.note) {
      this.note = null;
      if (this.s) this.publish({ ...this.s, note: null });
    }
    return { ok: true };
  }

  private ignored(what: string): PanelResult {
    const boeing = this.s?.family === "boeing";
    const error = `${what} didn't respond. ${boeing ? "PMDG, iFly and some other add-on aircraft ignore the simulator's standard commands." : "This aircraft may handle it internally."}`;
    this.note = error;
    if (this.s) this.publish({ ...this.s, note: error });
    return { ok: false, error };
  }

  async setLight(id: LightId, on: boolean): Promise<PanelResult> {
    if (!this.h || !this.s) return { ok: false, error: "Simulator not connected." };
    if (this.s.lights[id] === on) return { ok: true };
    this.fire(LIGHT_EVENTS[id], 0);
    if (await this.until(() => this.s?.lights[id] === on)) return this.worked();
    // Add-on switches: try the aircraft's own input event if it has one.
    const alt = INPUT_EVENT_LIGHTS[id];
    const hash = alt?.names.map((n) => this.inputs.get(n)).find((x) => x !== undefined);
    if (alt && hash !== undefined) {
      this.h.setInputEvent(hash, on ? alt.on : 0);
      if (await this.until(() => this.s?.lights[id] === on)) return this.worked();
    }
    return this.ignored(`The ${LABELS[id].toLowerCase()} light`);
  }

  async press(ctl: ApButton): Promise<PanelResult> {
    if (!this.h || !this.s?.ap) return { ok: false, error: "This aircraft isn't reporting its autopilot." };
    const { event, flag } = BUTTON_EVENTS[ctl];
    const before = this.s.ap[flag];
    this.fire(event, 0);
    if (await this.until(() => this.s?.ap?.[flag] !== before)) return this.worked();
    return this.ignored("That button");
  }

  async set(ctl: ApKnob, value: number): Promise<PanelResult> {
    if (!this.h || !this.s?.ap) return { ok: false, error: "This aircraft isn't reporting its autopilot." };
    const mach = ctl === "spd" && this.s.ap.machMode;
    this.fire(SET_EVENTS[ctl] === "AP_SPD_VAR_SET" && mach ? "AP_MACH_VAR_SET" : SET_EVENTS[ctl], mach ? Math.round(value * 100) : Math.round(value));
    const ok = () => {
      const ap = this.s?.ap;
      if (!ap) return false;
      switch (ctl) {
        case "spd":
          return Math.abs(ap.spd - value) <= (ap.machMode ? 0.006 : 1);
        case "hdg":
          return angleDiff(ap.hdg, value) <= 1;
        case "crs":
          return angleDiff(ap.crs, value) <= 1;
        case "alt":
          return Math.abs(ap.alt - value) <= 50;
        default:
          return Math.abs(ap.vsFpm - value) <= 50;
      }
    };
    if (await this.until(ok)) return this.worked();
    return this.ignored("That window");
  }
}
