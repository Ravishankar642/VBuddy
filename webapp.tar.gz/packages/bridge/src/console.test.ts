import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { TelemetryHub } from "./hub.js";
import { startServer, type ConsoleHooks } from "./server.js";
import { LandingStore } from "./landing/store.js";
import { logger } from "./log.js";
import { FakeSource } from "./test-helpers.js";
import { loadRelayIdentity, makeIdentity, phoneLink } from "./relay/identity.js";
import { readPrefs, writePrefs } from "./relay/console-prefs.js";
import { isBridgeId, isBridgeKey } from "@vbuddy/protocol";

async function rig() {
  const calls: Array<[string, Record<string, unknown>]> = [];
  const hooks: ConsoleHooks = { info: () => ({ version: "t", relay: { enabled: false } }), act: (a, b) => void calls.push([a, b]) };
  const server = await startServer({ console: hooks, relay: { tag: "tag", access: "paired", id: "abcd2345wxyz" }, hub: new TelemetryHub(new FakeSource(), 50, 1), landings: new LandingStore(null, logger("test")), host: "127.0.0.1", port: 0, webDir: null });
  return { server, calls, base: `http://127.0.0.1:${(server.http.address() as { port: number }).port}` };
}

test("console: only a browser on this PC, opened as localhost, may read or change things", async () => {
  const { server, calls, base } = await rig();
  try {
    const ok = await fetch(base + "/api/console");
    assert.equal(ok.status, 200);
    assert.equal(((await ok.json()) as { version: string }).version, "t");
    // Through the relay (it presents this run's tag), the window is not reachable.
    assert.equal((await fetch(base + "/api/console", { headers: { "x-vbuddy-relay": "tag", "x-vbuddy-remote": "203.0.113.5" } })).status, 404);
    // Forwarded by a proxy, or reached by another host name (DNS rebinding): refused.
    assert.equal((await fetch(base + "/api/console", { headers: { "x-forwarded-for": "203.0.113.5" } })).status, 404);
    // Changes need the custom header (a web page can't send it without a preflight) and a same-origin Origin.
    const post = (headers: Record<string, string>, body = "{}") => fetch(base + "/api/console/relay", { method: "POST", headers, body });
    assert.equal((await post({})).status, 405);
    assert.equal((await post({ "x-vbuddy-console": "1", origin: "https://evil.example" })).status, 404);
    assert.equal(calls.length, 0);
    assert.equal((await post({ "x-vbuddy-console": "1", origin: new URL(base).origin }, '{"enabled":true}')).status, 200);
    assert.deepEqual(calls, [["relay", { enabled: true }]]);
    assert.equal((await fetch(base + "/api/console/nonsense", { method: "POST", headers: { "x-vbuddy-console": "1" } })).status, 405);
  } finally {
    await server.close();
  }
});

test("relay identity: made once, kept, and valid; the phone link carries only the id", () => {
  const dir = mkdtempSync(join(tmpdir(), "vbuddy-id-"));
  const file = join(dir, "relay-identity.json");
  const a = loadRelayIdentity(file);
  assert.ok(isBridgeId(a.id) && isBridgeKey(a.key));
  assert.deepEqual(loadRelayIdentity(file), a);
  assert.notDeepEqual(makeIdentity(), makeIdentity());
  const link = phoneLink("wss://vbuddy.duckdns.org/", a.id);
  assert.equal(link, `https://vbuddy.duckdns.org/?r=${a.id}`);
  assert.ok(!link.includes(a.key));
  assert.equal(phoneLink("ws://127.0.0.1:9", "abcd2345wxyz"), "http://127.0.0.1:9/?r=abcd2345wxyz");
});

test("console choices are saved and read back", () => {
  const file = join(mkdtempSync(join(tmpdir(), "vbuddy-prefs-")), "console-settings.json");
  assert.deepEqual(readPrefs(file), {});
  writePrefs(file, { relay: true });
  assert.deepEqual(readPrefs(file), { relay: true });
  writePrefs(file, { relay: false });
  assert.deepEqual(readPrefs(file), { relay: false });
  assert.deepEqual(readPrefs(null), {});
});
