import type { SimStatus, Telemetry } from "@vbuddy/protocol";

/**
 * Slow-changing or event-style values the landing analyzer needs that aren't
 * part of the main telemetry. Each field is null until the sim has delivered it
 * (or forever, if the sim rejected that variable), so consumers must cope with
 * nulls and fall back to estimating from the per-frame telemetry.
 */
export interface SimExtras {
  /**
   * The sim's own latch of the normal (vertical) velocity at the last touchdown, ft/s.
   * It keeps the previous landing's value until the next touchdown, so only trust
   * it when it has changed since before the landing. Sign is not relied on.
   */
  touchdownNormalVelFps: number | null;
  /** Ambient wind speed, knots. */
  windKt: number | null;
  /** Direction the wind blows FROM, degrees true. */
  windFromDeg: number | null;
}

export const EMPTY_EXTRAS: SimExtras = { touchdownNormalVelFps: null, windKt: null, windFromDeg: null };

/**
 * Anything that can produce aircraft telemetry: the real sim via SimConnect,
 * or the built-in mock flight. Sources push raw samples as fast as they get
 * them (every sim frame); the hub decides how often to forward them to clients,
 * and the landing analyzer consumes every one.
 */
export interface SimSource {
  start(): void;
  stop(): Promise<void>;
  onSample(cb: (t: Telemetry, at: number) => void): void;
  onExtras(cb: (e: SimExtras, at: number) => void): void;
  onStatus(cb: (s: SimStatus) => void): void;
  status(): SimStatus;
}

export const normDeg = (d: number) => ((d % 360) + 360) % 360;
