#!/usr/bin/env node
import { networkInterfaces } from "node:os";
import { DEFAULT_RELAY_URL, loadConfig } from "./config.js";
import { ensureSettingsFile } from "./env-file.js";
import { TelemetryHub } from "./hub.js";
import { logger } from "./log.js";
import { LandingAnalyzer } from "./landing/analyzer.js";
import { FlightDb } from "./db/flight-db.js";
import { importLandingsJsonl } from "./db/import-jsonl.js";
import { FlightRecorder } from "./db/recorder.js";
import { summarize } from "@vbuddy/protocol";
import { LandingStore } from "./landing/store.js";
import { SectorLoader } from "./network/sector-loader.js";
import { NetworkService } from "./network/service.js";
import { VatsimFeed } from "./network/vatsim-feed.js";
import { tmpdir } from "node:os";
import { Pairing } from "./control/pairing.js";
import { CockpitService } from "./cockpit/service.js";
import { MockCockpit } from "./cockpit/mock-cockpit.js";
import { FenixSim } from "./cockpit/fenix-sim.js";
import { startServer } from "./server.js";
import { RelayClient } from "./relay/relay-client.js";
import { loadRelayIdentity, phoneLink } from "./relay/identity.js";
import { readPrefs, writePrefs } from "./relay/console-prefs.js";
import { CommsService } from "./comms/service.js";
import { SimRadios } from "./comms/sim-radios.js";
import { MockRadios } from "./comms/mock-radios.js";
import { MockPlugin } from "./comms/mock-plugin.js";
import { PushService } from "./push/service.js";
import { PanelService } from "./panel/service.js";
import { SimPanel } from "./panel/sim-panel.js";
import { MockPanel } from "./panel/mock-panel.js";
import { randomBytes } from "node:crypto";
import { MockSource } from "./sim/mock-source.js";
import { SimConnectSource } from "./sim/simconnect-source.js";
import type { SimSource } from "./sim/source.js";
import { VERSION } from "./version.js";
import { join } from "node:path";

const log = logger("bridge");

function lanAddresses(): string[] {
  const out: string[] = [];
  for (const list of Object.values(networkInterfaces())) {
    for (const a of list ?? []) if (a.family === "IPv4" && !a.internal) out.push(a.address);
  }
  return out;
}

async function main() {
  let cfg;
  try {
    cfg = loadConfig();
  } catch (e) {
    console.error((e as Error).message);
    process.exit(2);
  }

  log.info(`VBuddy bridge ${VERSION} (${cfg.mock ? "MOCK flight" : "MSFS via SimConnect"})`);
  if (!cfg.mock && cfg.dataDir) {
    const settings = ensureSettingsFile(cfg.dataDir);
    if (settings) log.info(`Settings file: ${settings}`);
  }
  const source: SimSource = cfg.mock ? new MockSource({ quick: cfg.mockQuick }) : new SimConnectSource(cfg.simconnect);
  const hub = new TelemetryHub(source, cfg.telemetryHz, cfg.backlogMinutes);

  // The flight log: telemetry, flights and landings in one SQLite file. If it can't be opened the bridge still runs, just without history.
  const dbFile = cfg.dataDir ? join(cfg.dataDir, "flights.db") : null;
  const db = dbFile ? await FlightDb.open(dbFile, logger("flightlog")) : null;
  if (db && cfg.dataDir) await importLandingsJsonl(join(cfg.dataDir, "landings.jsonl"), db, logger("flightlog"));

  let recorder: FlightRecorder | null = null;
  if (db && cfg.keepHours > 0) {
    recorder = new FlightRecorder(db, hub.sessionId, cfg.mock ? "mock" : "simconnect", () => source.status().aircraftTitle ?? "", logger("flightlog"));
    hub.onFrame((f) => recorder!.onFrame(f));
    hub.onStatus((s) => recorder!.onStatus(s));
    hub.setArchive(recorder);
    recorder.prune(cfg.keepHours);
    recorder.start();
  }
  const pruneTimer = recorder ? setInterval(() => recorder!.prune(cfg.keepHours), 3_600_000) : null;
  pruneTimer?.unref();

  // Landing analysis sees every sim frame, not the 5 Hz client stream.
  const landings = new LandingStore(
    db ? { save: (l) => (recorder ? recorder.saveLanding(l) : void db.insertLanding(l, null)), loadRecent: (n) => db.recentLandingJson(n) } : null,
    logger("landings"),
  );
  landings.load();
  const analyzer = new LandingAnalyzer(() => ({
    aircraftTitle: source.status().aircraftTitle,
    source: cfg.mock ? "mock" : "simconnect",
  }));
  source.onSample((t, at) => analyzer.ingest(t, at));
  source.onExtras((x) => analyzer.setExtras(x));
  let lastTitle = "";
  source.onStatus((s) => {
    if (!s.connected) {
      analyzer.reset();
      lastTitle = "";
    } else if (s.aircraftTitle !== lastTitle) {
      // A different aircraft (or the first one after connecting): the sim reports odd values while it loads.
      if (lastTitle || s.aircraftTitle) analyzer.spawn();
      lastTitle = s.aircraftTitle;
    }
  });
  const lLog = logger("landing");
  analyzer.onLanding((l) => {
    const flags = [l.touchAndGo ? "touch-and-go" : "", l.bounces ? `${l.bounces} bounce(s)` : "", l.lowConfidence ? "low confidence" : ""].filter(Boolean);
    lLog.info(
      `Touchdown ${l.vsFpm} fpm (${l.vsSource}), ${l.gPeak.toFixed(2)} g, ${l.rating.toUpperCase()}` + (flags.length ? ` [${flags.join(", ")}]` : ""),
    );
    landings.add(l);
  });
  const flushTimer = setInterval(() => analyzer.flush(Date.now()), 1000);

  // Online network: traffic, ATC sectors and boundary alerts. Polls only while a client or the sim is connected.
  let server: Awaited<ReturnType<typeof startServer>> | undefined;
  let network: NetworkService | null = null;
  let sectorTimer: NodeJS.Timeout | null = null;
  if (cfg.network === "vatsim") {
    const nLog = logger("network");
    const feed = new VatsimFeed({
      log: nLog,
      feedUrl: cfg.networkUrls.feed,
      wanted: () => (server?.clientCount() ?? 0) > 0 || source.status().connected,
    });
    network = new NetworkService(feed, null, nLog, cfg.callsign);
    hub.onFrame((f) => network!.setOwn(f.data));
    hub.onStatus((s) => {
      if (!s.connected) network!.setOwn(null);
    });
    const loader = new SectorLoader({
      dir: cfg.dataDir ? join(cfg.dataDir, "network") : join(tmpdir(), "vbuddy-network"),
      log: nLog,
      vatspyBase: cfg.networkUrls.vatspyBase,
      traconUrl: cfg.networkUrls.tracon,
    });
    const loadSectors = () => void loader.load().then((s) => s && network!.setSectors(s));
    loadSectors();
    sectorTimer = setInterval(loadSectors, 24 * 3_600_000);
    sectorTimer.unref();
  }

  // Cockpit control: the Fenix FCU (or a pretend one with the mock flight), only for paired devices and this PC.
  let cockpit: CockpitService | null = null;
  let pairing: Pairing | null = null;
  if (cfg.control) {
    const cLog = logger("cockpit");
    const backend = source instanceof SimConnectSource ? new FenixSim(source, cLog) : new MockCockpit();
    cockpit = new CockpitService(backend, cLog);
    pairing = new Pairing(cfg.dataDir ? join(cfg.dataDir, "paired-devices.json") : null, logger("pairing"));
  }

  // Phone notifications: sent straight from this PC to the browser's push service. Only paired devices can subscribe.
  let push: PushService | null = null;
  if (cfg.push && pairing) {
    push = new PushService(cfg.dataDir ? join(cfg.dataDir, "push-subscriptions.json") : null, cfg.dataDir ? join(cfg.dataDir, "push-vapid.json") : null, cfg.pushContact, logger("push"));
    landings.onAdd((l) => {
      void push!.notifyLanding(summarize(l));
    });
    network?.onAlert((a) => {
      void push!.notifyAtc(a);
    });
  }
  // Radios, transponder, VATSIM connection and chat. The radios come from the sim; chat and connect go through the vPilot plugin.
  const comms = new CommsService(source instanceof SimConnectSource ? new SimRadios(source) : new MockRadios(), logger("comms"), cfg.dataDir ? join(cfg.dataDir, "comms-identity.json") : null);
  if (push) {
    comms.onChat((m) => {
      if (m.attention && m.dir === "in") void push!.notifyChat(m);
    });
  }
  // Cockpit controls are Airbus-only for now. The PMDG backend (src/pmdg) is finished but not wired in until its SDK files are available:
  // new PmdgPanel(source, new SimPanel(source), logger("pmdg"), { sdkDirs: [join(process.cwd(), "sdk")] })
  const panelBackend = source instanceof SimConnectSource ? new SimPanel(source) : new MockPanel(cfg.mockAircraft);
  const panel = new PanelService(panelBackend, logger("panel"));
  const mockPlugin = cfg.mock ? new MockPlugin(comms) : null;
  const relayTag = randomBytes(24).toString("base64url");

  // The cloud relay: this install's own id and key (made on first run) pick this PC on a shared relay; nothing secret is built in.
  const identity = loadRelayIdentity(cfg.dataDir ? join(cfg.dataDir, "relay-identity.json") : null);
  const prefsFile = cfg.dataDir ? join(cfg.dataDir, "console-settings.json") : null;
  let relayOn = readPrefs(prefsFile).relay ?? cfg.relayOn ?? false;
  const relayClient = new RelayClient({ url: cfg.relayUrl, id: identity.id, key: identity.key, localPort: cfg.port, tag: relayTag, name: process.env.COMPUTERNAME ?? process.env.HOSTNAME ?? "bridge", log: logger("relay") });

  const consoleInfo = () => {
    const p = pairing?.current() ?? null;
    return {
      version: VERSION,
      port: cfg.port,
      mock: cfg.mock,
      addresses: cfg.host === "0.0.0.0" ? lanAddresses().map((a) => `http://${a}:${cfg.port}`) : [`http://${cfg.host}:${cfg.port}`],
      sim: { connected: source.status().connected, aircraft: source.status().aircraftTitle || null },
      vpilot: { linked: comms.state().net.pluginLinked },
      clients: server?.clientCount() ?? 0,
      pairing: p ? { code: p.code, expiresAt: p.expiresAt } : null,
      devices: pairing?.devicesList() ?? [],
      relay: {
        enabled: relayOn,
        state: relayClient.state,
        url: cfg.relayUrl,
        shared: cfg.relayUrl === DEFAULT_RELAY_URL,
        id: identity.id,
        phoneLink: phoneLink(cfg.relayUrl, identity.id),
        access: cfg.relayAccess,
        error: relayOn ? relayClient.lastError : "",
      },
      dataDir: cfg.dataDir,
    };
  };
  const consoleAct = (action: "relay" | "newCode" | "forget", body: Record<string, unknown>) => {
    if (action === "relay") {
      relayOn = body.enabled === true;
      writePrefs(prefsFile, { relay: relayOn });
      if (relayOn) relayClient.start();
      else relayClient.stop();
      log.info(`Relay: ${relayOn ? "switched on" : "switched off"} from the VBuddy window`);
    } else if (action === "newCode") {
      pairing?.rotate();
    } else if (action === "forget" && typeof body.id === "string") {
      pairing?.revoke(body.id);
    }
  };

  try {
    server = await startServer({ console: { info: consoleInfo, act: consoleAct }, panel, comms, relay: { tag: relayTag, access: cfg.relayAccess, id: identity.id }, push, hub, landings, history: recorder, network, cockpit, pairing, host: cfg.host, port: cfg.port, webDir: cfg.webDir });
  } catch (e) {
    const err = e as NodeJS.ErrnoException;
    if (err.code === "EADDRINUSE") log.error(`Port ${cfg.port} is already in use. Is another bridge running? Use --port to pick another.`);
    else log.error(`Could not start the server: ${err.message}`);
    process.exit(1);
  }

  if (relayOn) relayClient.start();

  mockPlugin?.start();
  source.start();
  hub.start();
  network?.start();

  const urls = cfg.host === "0.0.0.0" ? ["localhost", ...lanAddresses()] : [cfg.host];
  log.info(cockpit ? "Cockpit control: on (this PC and paired devices)" : "Cockpit control: off");
  log.info(cfg.mock ? "vPilot link: mock (pretend VATSIM session)" : "vPilot link: waiting for the VBuddy Link plugin (ws://127.0.0.1:" + cfg.port + "/plugin)");
  log.info(relayOn ? `Relay: ${cfg.relayUrl} (${cfg.relayAccess === "paired" ? "devices must pair" : "OPEN - anyone with the address can watch"}). Phone link: ${phoneLink(cfg.relayUrl, identity.id)}` : "Relay: off (switch it on in the VBuddy window for access away from home)");
  log.info(push ? "Notifications: on (paired devices can turn them on in the app)" : cfg.push && !pairing ? "Notifications: off (needs --control on)" : "Notifications: off");
  log.info(network ? `Online network: VATSIM${cfg.callsign ? ` (callsign ${cfg.callsign})` : ""}` : "Online network: off");
  log.info(`Telemetry at ${cfg.telemetryHz} Hz, ${cfg.backlogMinutes} min replay buffer`);
  if (cfg.webDir) {
    log.info("Open VBuddy on your phone/tablet (same Wi-Fi):");
    for (const u of urls) log.info(`   http://${u}:${cfg.port}`);
  } else {
    log.warn("Web client not built: only the WebSocket is available. Run `pnpm build` or `pnpm dev`.");
  }
  if (!db) log.info(cfg.dataDir ? "Flight log: OFF (see the warning above). Landings are kept in memory only." : "Flight log: memory only (not saved). Use --data-dir to save it.");
  else if (recorder) log.info(`Flight log: ${db.file} (telemetry kept ${cfg.keepHours} h; ${db.landingCount()} landing(s) saved)`);
  else log.info(`Flight log: ${db.file} (landings only; telemetry recording is off)`);
  if (cfg.host === "0.0.0.0") {
    log.info(`If other devices can't connect, allow Node.js (or TCP port ${cfg.port}) through Windows Firewall on Private networks.`);
  }

  let stopping = false;
  const shutdown = async (sig: string) => {
    if (stopping) process.exit(1);
    stopping = true;
    log.info(`${sig}: shutting down`);
    hub.stop();
    network?.stop();
    relayClient.stop();
    mockPlugin?.stop();
    if (sectorTimer) clearInterval(sectorTimer);
    clearInterval(flushTimer);
    if (pruneTimer) clearInterval(pruneTimer);
    await source.stop(); // a landing still open when the sim goes away is finished by the status handler
    recorder?.stop();
    await server!.close();
    db?.close();
    process.exit(0);
  };
  process.on("SIGINT", () => void shutdown("SIGINT"));
  process.on("SIGTERM", () => void shutdown("SIGTERM"));
}

void main();
