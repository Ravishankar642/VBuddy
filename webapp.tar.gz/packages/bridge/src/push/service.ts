import { formatMhz, type AtcAlert, type ChatMessage, type LandingSummary, type PushInfoMsg, type PushPrefs } from "@vbuddy/protocol";
import { mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { dirname } from "node:path";
import webpush from "web-push";
import type { Logger } from "../log.js";

export interface PushSubscriptionJson {
  endpoint: string;
  keys: { p256dh: string; auth: string };
}
interface Saved {
  deviceId: string;
  subscription: PushSubscriptionJson;
  prefs: PushPrefs;
}
export interface PushPayload {
  title: string;
  body: string;
  /** Same tag replaces an earlier notification instead of stacking. */
  tag: string;
  kind: "atc" | "landing" | "chat" | "test";
  url: string;
}
export type PushSender = (sub: PushSubscriptionJson, payload: string, opts: { TTL: number; urgency: "normal" | "high" }) => Promise<{ statusCode: number }>;

export const DEFAULT_PREFS: PushPrefs = { atc: true, landing: true, chat: true };

/**
 * Web Push from the bridge itself: the browser's push service (Google, Apple, Mozilla) is reachable from the
 * PC, so no extra server is needed. Subscriptions belong to paired devices; revoking a device removes its subscription.
 */
export class PushService {
  private subs: Saved[] = [];
  readonly publicKey: string;
  private privateKey: string;
  private sender: PushSender;

  constructor(
    private file: string | null,
    vapidFile: string | null,
    private contact: string,
    private log: Logger,
    sender?: PushSender,
  ) {
    const keys = this.loadKeys(vapidFile);
    this.publicKey = keys.publicKey;
    this.privateKey = keys.privateKey;
    this.sender =
      sender ??
      ((sub, payload, o) =>
        webpush.sendNotification(sub, payload, { TTL: o.TTL, urgency: o.urgency, vapidDetails: { subject: this.contact, publicKey: this.publicKey, privateKey: this.privateKey } }).then((r) => ({ statusCode: r.statusCode })));
    this.load();
  }

  private loadKeys(file: string | null): { publicKey: string; privateKey: string } {
    if (file) {
      try {
        const j = JSON.parse(readFileSync(file, "utf8")) as { publicKey?: string; privateKey?: string };
        if (j.publicKey && j.privateKey) return { publicKey: j.publicKey, privateKey: j.privateKey };
      } catch {
        /* make new ones below */
      }
    }
    const k = webpush.generateVAPIDKeys();
    if (file) {
      try {
        mkdirSync(dirname(file), { recursive: true });
        writeFileSync(file, JSON.stringify(k), { mode: 0o600 });
      } catch (e) {
        this.log.warn(`Couldn't save the push keys (${(e as Error).message}); devices will need to turn notifications on again after a restart.`);
      }
    }
    return k;
  }

  private load() {
    if (!this.file) return;
    try {
      const j = JSON.parse(readFileSync(this.file, "utf8")) as { subs?: Saved[] };
      this.subs = (j.subs ?? []).filter((s) => s?.deviceId && s.subscription?.endpoint && s.subscription.keys);
    } catch (e) {
      if ((e as NodeJS.ErrnoException).code !== "ENOENT") this.log.warn(`Couldn't read saved notification subscriptions (${(e as Error).message}).`);
    }
  }
  private save() {
    if (!this.file) return;
    try {
      mkdirSync(dirname(this.file), { recursive: true });
      writeFileSync(this.file + ".tmp", JSON.stringify({ subs: this.subs }, null, 2), { mode: 0o600 });
      renameSync(this.file + ".tmp", this.file);
    } catch (e) {
      this.log.warn(`Couldn't save notification subscriptions: ${(e as Error).message}`);
    }
  }

  info(deviceId: string | null): Omit<PushInfoMsg, "t" | "v" | "ts"> {
    const s = deviceId ? this.subs.find((x) => x.deviceId === deviceId) : undefined;
    return { enabled: true, publicKey: this.publicKey, subscribed: !!s, prefs: { ...DEFAULT_PREFS, ...(s?.prefs ?? {}) } };
  }

  subscribe(deviceId: string, subscription: PushSubscriptionJson, prefs: PushPrefs) {
    // One subscription per device, and one device per browser endpoint.
    this.subs = this.subs.filter((s) => s.deviceId !== deviceId && s.subscription.endpoint !== subscription.endpoint);
    this.subs.push({ deviceId, subscription, prefs });
    this.save();
  }
  unsubscribe(deviceId: string) {
    const n = this.subs.length;
    this.subs = this.subs.filter((s) => s.deviceId !== deviceId);
    if (this.subs.length !== n) this.save();
  }
  count() {
    return this.subs.length;
  }

  private async deliver(targets: Saved[], p: PushPayload, ttl: number, urgency: "normal" | "high") {
    const payload = JSON.stringify(p);
    const dead: string[] = [];
    await Promise.all(
      targets.map(async (t) => {
        try {
          await this.sender(t.subscription, payload, { TTL: ttl, urgency });
        } catch (e) {
          const code = (e as { statusCode?: number }).statusCode;
          if (code === 404 || code === 410) dead.push(t.deviceId);
          else this.log.warn(`Push to a device failed (${code ?? (e as Error).message})`);
        }
      }),
    );
    if (dead.length) {
      this.subs = this.subs.filter((s) => !dead.includes(s.deviceId));
      this.save();
      this.log.info(`Removed ${dead.length} notification subscription(s) the browser no longer accepts`);
    }
    return targets.length - dead.length;
  }

  notifyAtc(a: AtcAlert) {
    const title = a.kind === "ahead" ? "ATC boundary ahead" : a.kind === "unicom" ? "No ATC coverage" : "Contact ATC";
    return this.deliver(this.subs.filter((s) => s.prefs.atc), { title, body: a.text, tag: "atc", kind: "atc", url: "/#map" }, 120, "high");
  }
  notifyChat(m: ChatMessage) {
    const title = m.kind === "private" ? `Message from ${m.from}` : m.kind === "selcal" ? `SELCAL from ${m.from}` : `${m.from}${m.freqHz[0] ? " " + formatMhz(m.freqHz[0]) : ""}`;
    return this.deliver(this.subs.filter((s) => s.prefs.chat !== false), { title, body: m.text.slice(0, 180), tag: m.kind === "private" ? `dm-${m.from}` : "chat", kind: "chat", url: "/#comms" }, 300, "high");
  }
  notifyLanding(l: LandingSummary) {
    const flags = [l.touchAndGo ? "touch-and-go" : "", l.bounces ? `${l.bounces} bounce${l.bounces > 1 ? "s" : ""}` : ""].filter(Boolean);
    const body = `${Math.abs(l.vsFpm)} fpm, ${l.gPeak.toFixed(2)} g${flags.length ? ", " + flags.join(", ") : ""}`;
    return this.deliver(
      this.subs.filter((s) => s.prefs.landing),
      { title: `Touchdown: ${l.rating.toUpperCase()}`, body, tag: `landing-${l.id}`, kind: "landing", url: "/#landing" },
      3600,
      "normal",
    );
  }
  async test(deviceId: string) {
    const t = this.subs.filter((s) => s.deviceId === deviceId);
    if (!t.length) return false;
    return (await this.deliver(t, { title: "VBuddy", body: "Notifications are working.", tag: "test", kind: "test", url: "/" }, 60, "high")) > 0;
  }
}
