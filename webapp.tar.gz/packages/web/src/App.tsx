import { lazy, Suspense, useEffect, useState, type ReactNode } from "react";
import type { Telemetry } from "@vbuddy/protocol";
import { AppCard, UpdateBanner } from "./components/AppCard";
import { AtcCard } from "./components/AtcCard";
import { CockpitView, PairThisDevice } from "./components/Cockpit";
import { CommsView } from "./components/CommsView";
import { VatsimPill, ZuluClock } from "./components/StatusBar";
import { playChime, unlockAudioOnFirstTouch } from "./lib/chime";
import { NotifyCard } from "./components/NotifyCard";
import { Flag, Tile } from "./components/ui";
import { LandingView, RatingBadge } from "./components/LandingView";
import { onAttention, useBridge, useBridgeActions, useNow } from "./lib/useBridge";
import { ago, coord, fixed, hdg, int, signed } from "./lib/format";

function Instruments({ t }: { t: Telemetry }) {
  const vsTone = Math.abs(t.vs) > 4000 ? "warn" : undefined;
  return (
    <div className="grid">
      <Tile label="Altitude" value={int(t.altMsl)} unit="ft" sub={`AGL ${int(t.altAgl)} ft`} />
      <Tile label="Indicated airspeed" value={int(t.ias)} unit="kt" sub={`TAS ${int(t.tas)} · M${fixed(t.mach, 2)}`} />
      <Tile label="Vertical speed" value={signed(t.vs)} unit="fpm" tone={vsTone} />
      <Tile label="Heading" value={hdg(t.hdgMag)} unit="°M" sub={`TRK ${hdg(t.track)}°T`} />
      <Tile label="Ground speed" value={int(t.gs)} unit="kt" />
      <Tile label="Attitude" value={<>{signed(t.pitch)}° <span className="sep">/</span> {signed(t.bank)}°</>} sub="pitch / bank" />
      <Tile label="G load" value={fixed(t.gForce, 2)} unit="g" tone={t.gForce > 1.6 || t.gForce < 0.4 ? "warn" : undefined} />
      <Tile label="Position" value={<span className="coord">{coord(t.lat, true)}<br />{coord(t.lon, false)}</span>} sub={`Ground ${int(t.groundElev)} ft`} />
      <section className="tile tile--wide">
        <h2 className="tile__label">Aircraft state</h2>
        <div className="flags">
          <Flag on={t.onGround}>{t.onGround ? "On ground" : "Airborne"}</Flag>
          <Flag on={t.gearDown}>Gear {t.gearDown ? "down" : "up"}</Flag>
          <Flag on={t.flapsIndex > 0}>Flaps {t.flapsIndex}</Flag>
          <Flag on={t.parkingBrake}>Park brake</Flag>
          {t.simRate !== 1 && <Flag on>Sim rate ×{t.simRate}</Flag>}
        </div>
      </section>
      <section className="tile tile--wide">
        <h2 className="tile__label">Autopilot (selected)</h2>
        <div className="ap">
          <Flag on={t.ap.master}>AP {t.ap.master ? "ON" : "OFF"}</Flag>
          <span>SPD <b>{int(t.ap.spdSel)}</b></span>
          <span>HDG <b>{hdg(t.ap.hdgSel)}</b></span>
          <span>ALT <b>{int(t.ap.altSel)}</b></span>
          <span>V/S <b>{signed(t.ap.vsSel)}</b></span>
        </div>
      </section>
    </div>
  );
}

// The map (and Leaflet) loads only when the Map tab is first opened.
const MapView = lazy(() => import("./components/MapView"));

type Tab = "flight" | "cockpit" | "comms" | "map" | "landing";
const TABS: Array<[Tab, string]> = [
  ["flight", "Flight"],
  ["cockpit", "Cockpit"],
  ["comms", "Comms"],
  ["map", "Map"],
  ["landing", "Landings"],
];
const tabFromHash = (): Tab => {
  const h = window.location.hash.slice(1);
  return h === "landing" || h === "map" || h === "cockpit" || h === "comms" ? h : "flight";
};

/** The tab lives in the URL hash so a reload (or a shared link) lands on the same one. */
function useTab(): [Tab, (t: Tab) => void] {
  const [tab, setTab] = useState<Tab>(tabFromHash);
  useEffect(() => {
    const on = () => setTab(tabFromHash());
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  return [tab, (t) => (window.location.hash = `#${t}`)];
}

const TOAST_MS = 30_000;
const ATC_TOAST_MS = 25_000;

export function App() {
  const b = useBridge();
  const { dismissNewLanding, dismissAtcAlert, dismissAttention } = useBridgeActions();
  const [tab, setTab] = useTab();
  const now = useNow(500);
  const t = b.latest?.data ?? null;
  const age = b.latest ? now - b.latest.ts : Infinity;

  let banner: ReactNode = null;
  if (b.control?.locked) banner = null;
  else if (b.link === "waiting") banner = <>Can't reach the VBuddy bridge. Retrying in {b.retryIn}s…</>;
  else if (b.link === "connecting") banner = <>Connecting to the bridge…</>;
  else if (b.sim && !b.sim.connected) banner = <>Bridge is running, waiting for MSFS{b.sim.detail ? ` (${b.sim.detail})` : ""}.</>;
  else if (b.sim?.paused) banner = <>Simulator paused.</>;

  const locked = !!b.control?.locked;
  const linkTone = locked ? "partial" : b.link === "open" ? (b.sim?.connected ? "ok" : "partial") : "down";
  const linkText = locked ? "Pair device" : b.link === "open" ? (b.sim?.connected ? (b.sim.source === "mock" ? "Mock flight" : "Live") : "No sim") : "Offline";

  // A landing that happens while you're on the Flight tab (or while the tablet was offline) gets a toast.
  const toast = tab === "flight" ? b.newLanding : null;
  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(dismissNewLanding, TOAST_MS);
    return () => clearTimeout(id);
  }, [toast, dismissNewLanding]);

  // A chime for each ATC call or DM that arrives while the app is open; the badge and push cover the rest.
  useEffect(() => {
    unlockAudioOnFirstTouch();
    const off = onAttention(() => void playChime());
    return () => {
      off();
    };
  }, []);
  // Unread count on the home-screen icon where the browser supports it.
  useEffect(() => {
    const nav = navigator as Navigator & { setAppBadge?: (n?: number) => Promise<void>; clearAppBadge?: () => Promise<void> };
    try {
      if (b.attentionUnread > 0) void nav.setAppBadge?.(b.attentionUnread);
      else void nav.clearAppBadge?.();
    } catch {
      /* not supported */
    }
  }, [b.attentionUnread]);
  const msgToast = tab === "comms" ? null : b.lastAttention;
  useEffect(() => {
    if (!msgToast) return;
    const id = setTimeout(dismissAttention, 15_000);
    return () => clearTimeout(id);
  }, [msgToast, dismissAttention]);

  const atcAlert = b.atcAlert;
  useEffect(() => {
    if (!atcAlert) return;
    const id = setTimeout(dismissAtcAlert, ATC_TOAST_MS);
    return () => clearTimeout(id);
  }, [atcAlert, dismissAtcAlert]);

  return (
    <div className="app">
      <header className="top">
        <div className="brand">
          VBuddy<span className="brand__tag">preview</span>
        </div>
        <div className="top__status">
          <ZuluClock />
          <VatsimPill b={b} />
          <div className={`pill pill--${linkTone}`}>
            <i />
            {linkText}
          </div>
        </div>
      </header>

      <nav className="tabs" aria-label="Sections">
        {TABS.map(([k, label]) => (
          <button key={k} type="button" aria-current={tab === k ? "page" : undefined} onClick={() => setTab(k)}>
            {label}
            {k === "landing" && b.landings.length > 0 && <span className="tabs__count">{b.landings.length}</span>}
            {k === "comms" && b.attentionUnread > 0 && (
              <span className="tabs__badge" aria-label={`${b.attentionUnread} unread`}>
                {b.attentionUnread > 9 ? "9+" : b.attentionUnread}
              </span>
            )}
          </button>
        ))}
      </nav>

      <UpdateBanner />
      {!locked && <div className="aircraft">{b.sim?.aircraftTitle || "No aircraft"}</div>}
      {banner && <div className="banner">{banner}</div>}

      {atcAlert && (
        <div className="toast toast--atc" role="status" aria-live="polite">
          <span className="toast__icon" aria-hidden="true">
            {atcAlert.kind === "ahead" ? "↗" : "☎"}
          </span>
          <span className="toast__text">
            <b>{atcAlert.kind === "ahead" ? "Coming up" : atcAlert.kind === "unicom" ? "Leaving ATC coverage" : "New controller"}</b>
            <span>{atcAlert.text}</span>
          </span>
          <button type="button" className="btn btn--ghost" aria-label="Dismiss" onClick={dismissAtcAlert}>
            ✕
          </button>
        </div>
      )}

      {msgToast && (
        <div className="toast toast--atc" role="status" aria-live="polite">
          <span className="toast__icon" aria-hidden="true">
            ✉
          </span>
          <span className="toast__text">
            <b>{msgToast.kind === "private" ? `Message from ${msgToast.from}` : msgToast.from}</b>
            <span>{msgToast.text.length > 90 ? msgToast.text.slice(0, 90) + "…" : msgToast.text}</span>
          </span>
          <button type="button" className="btn btn--primary" onClick={() => { dismissAttention(); setTab("comms"); }}>
            Open
          </button>
          <button type="button" className="btn btn--ghost" aria-label="Dismiss" onClick={dismissAttention}>
            ✕
          </button>
        </div>
      )}

      {toast && (
        <div className="toast" role="status">
          <RatingBadge rating={toast.rating} />
          <span className="toast__text">
            <b>{int(toast.vsFpm)} fpm</b>
            <span>touchdown · {fixed(toast.gPeak, 2)} g</span>
          </span>
          <button type="button" className="btn btn--primary" onClick={() => setTab("landing")}>
            View
          </button>
          <button type="button" className="btn btn--ghost" aria-label="Dismiss" onClick={dismissNewLanding}>
            ✕
          </button>
        </div>
      )}

      <main>
        {b.control?.locked ? (
          <PairThisDevice gate />
        ) : tab === "landing" ? (
          <LandingView b={b} />
        ) : tab === "cockpit" ? (
          <CockpitView b={b} />
        ) : tab === "comms" ? (
          <CommsView b={b} />
        ) : tab === "map" ? (
          <Suspense fallback={<div className="empty">Loading the map…</div>}>
            <MapView b={b} />
          </Suspense>
        ) : t ? (
          <div className={age > 3000 ? "stale" : undefined}>
            <Instruments t={t} />
            <AtcCard b={b} compact />
          </div>
        ) : (
          <div className="empty">No telemetry yet.</div>
        )}
        {tab === "flight" && !b.control?.locked && <NotifyCard b={b} />}
        {tab === "flight" && <AppCard />}
      </main>

      <footer className="foot">
        <span>Data {b.latest ? ago(age) : "—"}</span>
        <span>seq {b.latest?.seq ?? "—"}</span>
        <span>{b.telemetryHz || "—"} Hz</span>
        <span>
          replayed {b.replayedFrames}
          {b.replayedFromDisk > 0 && ` (${b.replayedFromDisk} from disk)`}
          {b.replayStride > 1 && `, every ${b.replayStride}th`}
        </span>
        <span>missed {b.missedFrames}</span>
        <span>reconnects {b.reconnects}</span>
        {b.sim?.simName && <span>{b.sim.simName}</span>}
        {b.bridgeVersion && <span>bridge v{b.bridgeVersion}</span>}
      </footer>
    </div>
  );
}
