import qrcode from "qrcode-generator";

/** What the bridge tells this window (see consoleInfo in the bridge's index.ts). */
interface Info {
  version: string;
  port: number;
  mock: boolean;
  addresses: string[];
  sim: { connected: boolean; aircraft: string | null };
  vpilot: { linked: boolean };
  clients: number;
  pairing: { code: string; expiresAt: number } | null;
  devices: Array<{ id: string; name: string; pairedAt: number; lastSeen: number | null }>;
  relay: { enabled: boolean; state: "off" | "connecting" | "connected"; url: string; shared: boolean; id: string; phoneLink: string; access: "paired" | "open"; error: string };
  dataDir: string | null;
}

const $ = <T extends HTMLElement>(id: string) => document.getElementById(id) as T;
let info: Info | null = null;
let busy = false;

function setText(el: HTMLElement, text: string) {
  if (el.textContent !== text) el.textContent = text;
}

function pill(id: string, state: "ok" | "wait" | "off", text: string) {
  $(id).className = `pill ${state === "off" ? "" : state}`;
  setText($(id + "Text"), text);
}

function qrImage(text: string): HTMLImageElement {
  const qr = qrcode(0, "M");
  qr.addData(text);
  qr.make();
  const img = new Image();
  img.src = qr.createDataURL(5, 0);
  img.alt = `QR code for ${text}`;
  return img;
}

function showQr(box: HTMLElement, text: string) {
  box.replaceChildren(qrImage(text));
  box.hidden = false;
}

async function copy(text: string, button: HTMLButtonElement) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const range = document.createRange();
    const t = document.createElement("textarea");
    t.value = text;
    document.body.append(t);
    t.select();
    document.execCommand("copy");
    t.remove();
    range.detach();
  }
  const was = button.textContent;
  button.textContent = "Copied";
  setTimeout(() => (button.textContent = was), 1200);
}

async function call(path: string, body?: unknown): Promise<Info | null> {
  const res = await fetch(path, body === undefined ? undefined : { method: "POST", headers: { "content-type": "application/json", "x-vbuddy-console": "1" }, body: JSON.stringify(body) });
  if (res.status === 404) throw new Error("not-local");
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const j = (await res.json()) as Info | { info: Info };
  return "info" in j ? j.info : j;
}

function banner(text: string | null) {
  const b = $("banner");
  b.hidden = text === null;
  if (text !== null) b.textContent = text;
}

function render(i: Info) {
  info = i;
  setText($("version"), `Version ${i.version}${i.mock ? " (test flight)" : ""}`);

  pill("pSim", i.sim.connected ? "ok" : "wait", i.sim.connected ? i.sim.aircraft || "Connected" : "Waiting for MSFS");
  pill("pVp", i.vpilot.linked ? "ok" : "off", i.vpilot.linked ? "Plugin connected" : "Plugin not connected");
  pill("pDev", i.clients > 0 ? "ok" : "off", i.clients === 1 ? "1 connected" : `${i.clients} connected`);

  // home Wi-Fi addresses
  const list = $("addresses");
  if (!i.addresses.length) {
    list.replaceChildren(Object.assign(document.createElement("p"), { className: "muted", textContent: "No network address found. Is this PC on Wi-Fi or Ethernet?" }));
  } else if (list.dataset.key !== i.addresses.join("|")) {
    list.dataset.key = i.addresses.join("|");
    list.replaceChildren(
      ...i.addresses.map((a) => {
        const row = document.createElement("div");
        row.className = "link";
        const code = document.createElement("code");
        code.textContent = a;
        const c = document.createElement("button");
        c.className = "btn";
        c.textContent = "Copy";
        c.onclick = () => void copy(a, c);
        const q = document.createElement("button");
        q.className = "btn";
        q.textContent = "QR";
        q.onclick = () => {
          const box = $("homeQr");
          if (!box.hidden && box.dataset.for === a) box.hidden = true;
          else {
            box.dataset.for = a;
            showQr(box, a);
          }
        };
        row.append(code, c, q);
        return row;
      }),
    );
  }

  // pairing code
  const cc = $("codeCard");
  cc.hidden = !i.pairing;
  if (i.pairing) {
    setText($("code"), i.pairing.code);
    const s = Math.max(0, Math.round((i.pairing.expiresAt - Date.now()) / 1000));
    setText($("codeTtl"), `Changes in ${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`);
  }

  // relay
  const r = i.relay;
  const sw = $<HTMLInputElement>("relayOn");
  if (!busy) sw.checked = r.enabled;
  setText(
    $("relayText"),
    r.shared
      ? "Use VBuddy from anywhere, on mobile data or another Wi-Fi, with no router setup. Your flight data passes through the VBuddy relay server while this is on, and a device must be paired with the code above before it sees anything."
      : `Using your own relay (${r.url}). A device must be paired with the code above before it sees anything.`,
  );
  $("relayLink").hidden = !r.enabled;
  setText($("relayUrl"), r.phoneLink);
  const st = $("relayStatus");
  if (!r.enabled) {
    st.className = "status muted";
    setText(st, "Off");
  } else if (r.state === "connected") {
    st.className = "status ok";
    setText(st, "Connected. Open the link on your phone, then enter the pairing code.");
  } else {
    st.className = r.error ? "status bad" : "status wait";
    setText(st, r.error ? `Can't connect: ${r.error}. Retrying…` : "Connecting…");
  }
  if (r.access === "open") setText(st, st.textContent + " (open access: anyone with the link can watch)");

  // devices
  const ul = $("devices");
  $("noDevices").hidden = i.devices.length > 0;
  ul.replaceChildren(
    ...i.devices.map((d) => {
      const li = document.createElement("li");
      const name = document.createElement("span");
      name.textContent = d.name;
      const when = document.createElement("small");
      when.textContent = d.lastSeen ? `last seen ${new Date(d.lastSeen).toLocaleString()}` : "never connected";
      const b = document.createElement("button");
      b.className = "btn";
      b.textContent = "Forget";
      b.onclick = () => void act("forget", { id: d.id });
      li.append(name, when, b);
      return li;
    }),
  );
  setText($("dataDir"), i.dataDir ? `Settings and logs: ${i.dataDir}` : "");
}

async function act(name: "relay" | "newCode" | "forget", body: object = {}) {
  busy = true;
  try {
    const next = await call(`/api/console/${name}`, body);
    if (next) render(next);
    banner(null);
  } catch (e) {
    banner(`That didn't work (${(e as Error).message}).`);
  } finally {
    busy = false;
  }
}

async function poll() {
  try {
    const i = await call("/api/console");
    banner(null);
    if (i && !busy) render(i);
  } catch (e) {
    banner((e as Error).message === "not-local" ? "This window only works on the PC where VBuddy is running (open http://localhost:4789/console.html there)." : "VBuddy isn't running. Start it from the Start menu, then this window reconnects by itself.");
  }
}

$("newCode").onclick = () => void act("newCode");
$<HTMLInputElement>("relayOn").onchange = (e) => void act("relay", { enabled: (e.target as HTMLInputElement).checked });
$<HTMLButtonElement>("copyRelay").onclick = (e) => info && void copy(info.relay.phoneLink, e.target as HTMLButtonElement);
$<HTMLButtonElement>("qrRelay").onclick = () => {
  if (!info) return;
  const box = $("relayQr");
  if (box.hidden) showQr(box, info.relay.phoneLink);
  else box.hidden = true;
};

void poll();
setInterval(() => void poll(), 2000);
setInterval(() => info?.pairing && setText($("codeTtl"), (() => { const s = Math.max(0, Math.round((info!.pairing!.expiresAt - Date.now()) / 1000)); return `Changes in ${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; })()), 1000);
