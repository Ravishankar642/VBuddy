import { useState } from "react";
import type { PushPrefs } from "@vbuddy/protocol";
import type { BridgeSnapshot } from "../lib/bridge-client";
import { useBridgeActions } from "../lib/useBridge";
import { pushSupport, subscribeBrowser, unsubscribeBrowser } from "../lib/push";

const WHY: Record<string, string> = {
  insecure: "Notifications need a secure (https) address, like your relay. They can't work on a plain http://192.168… address.",
  "ios-install": "On iPhone and iPad, add VBuddy to your Home Screen first (Share → Add to Home Screen), then open it from there to turn notifications on.",
  unsupported: "This browser can't receive notifications.",
};

/** Phone/tablet notifications for ATC contact changes and touchdowns. Hidden when the bridge has them switched off. */
export function NotifyCard({ b }: { b: BridgeSnapshot }) {
  const { pushSubscribe, pushUnsubscribe, pushTest } = useBridgeActions();
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const p = b.push;
  if (!p) return null;
  const support = pushSupport();
  const paired = b.control?.reason === "paired";

  const turnOn = async (prefs: PushPrefs) => {
    if (!p.publicKey) return;
    setBusy(true);
    setErr(null);
    const r = await subscribeBrowser(p.publicKey);
    setBusy(false);
    if (r.ok) pushSubscribe(r.sub, prefs);
    else setErr(r.error);
  };
  const turnOff = async () => {
    await unsubscribeBrowser();
    pushUnsubscribe();
  };
  const setPref = (k: keyof PushPrefs, v: boolean) => {
    const next = { ...p.prefs, [k]: v };
    if (p.subscribed) void turnOn(next);
  };

  return (
    <section className="card notify">
      <h2 className="card__title">Notifications</h2>
      {!paired ? (
        <p className="muted">Pair this device on the Cockpit tab to get notifications when VBuddy isn't open.</p>
      ) : support !== "ok" ? (
        <p className="muted">{WHY[support]}</p>
      ) : (
        <>
          <p className="muted">Get a message on this device when ATC or a pilot messages you, a new controller takes over, a boundary is coming up, or you touch down, even with VBuddy closed.</p>
          {p.subscribed && (
            <div className="notify__prefs">
              <label>
                <input type="checkbox" checked={p.prefs.atc} onChange={(e) => setPref("atc", e.target.checked)} /> ATC changes
              </label>
              <label>
                <input type="checkbox" checked={p.prefs.chat} onChange={(e) => setPref("chat", e.target.checked)} /> Messages (DMs, ATC calls to you)
              </label>
              <label>
                <input type="checkbox" checked={p.prefs.landing} onChange={(e) => setPref("landing", e.target.checked)} /> Touchdown result
              </label>
            </div>
          )}
          <div className="notify__row">
            {p.subscribed ? (
              <>
                <button type="button" className="btn" onClick={pushTest}>
                  Send a test
                </button>
                <button type="button" className="btn btn--ghost" onClick={turnOff}>
                  Turn off
                </button>
              </>
            ) : (
              <button type="button" className="btn btn--primary" disabled={busy || !p.publicKey} onClick={() => void turnOn(p.prefs)}>
                {busy ? "Turning on…" : "Turn on notifications"}
              </button>
            )}
          </div>
        </>
      )}
      {(err || p.note) && (
        <p className={err ? "setval__err" : "muted"} role="status">
          {err ?? p.note}
        </p>
      )}
    </section>
  );
}
