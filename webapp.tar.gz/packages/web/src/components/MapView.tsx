import { useCallback, useEffect, useRef, useState } from "react";
import * as L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { AtcStation, NetPilot } from "@vbuddy/protocol";
import type { BridgeSnapshot } from "../lib/bridge-client";
import { useBridgeActions } from "../lib/useBridge";
import { apiFetch } from "../lib/api";
import { track, type TrackPoint } from "../lib/track";
import { hdg, int } from "../lib/format";
import { AtcCard, NetworkChip } from "./AtcCard";

// Esri Dark Gray Canvas: no API key needed. Base map plus a separate transparent labels layer.
const ESRI = "https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/";
const TILES = `${ESRI}World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}`;
const TILES_LABELS = `${ESRI}World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}`;
const TILE_ATTR = 'Tiles &copy; <a href="https://www.esri.com">Esri</a> &mdash; Esri, DeLorme, NAVTEQ';
const DATA_ATTR = 'ATC sectors: <a href="https://github.com/vatsimnetwork/vatspy-data-project">VATSpy data</a> (CC BY-SA 4.0), <a href="https://github.com/vatsimnetwork/simaware-tracon-project">SimAware TRACON</a>';
const PLANE = "M32 10 L36 28 L54 36 L54 40 L36 36 L35 48 L41 52 L41 55 L32 52 L23 55 L23 52 L29 48 L28 36 L10 40 L10 36 L28 28 Z";
const VIEW_KEY = "vbuddy.map.view";
const LABEL_ZOOM = 7;
const SECTOR_LABEL_ZOOM = 5;
const EXTRAPOLATE_MAX_S = 30;

const COLORS = { ctr: "#3987e5", fss: "#3987e5", app: "#b07de0", twr: "#e0a84f" } as const;

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
const planeIcon = (cls: string, size: number, label?: string) =>
  L.divIcon({
    className: "ac-wrap",
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    html: `<div class="ac ${cls}"><svg class="ac__icon" viewBox="0 0 64 64" width="${size}" height="${size}" aria-hidden="true"><path d="${PLANE}"/></svg>${label ? `<span class="ac__label">${esc(label)}</span>` : ""}</div>`,
  });
function rotate(m: L.Marker, deg: number) {
  const svg = m.getElement()?.querySelector<SVGElement>(".ac__icon");
  if (svg) svg.style.transform = `rotate(${deg}deg)`;
}
const R_NM = 3440.065;
function project(lat: number, lon: number, brg: number, nm: number): [number, number] {
  const d = nm / R_NM, p1 = (lat * Math.PI) / 180, b = (brg * Math.PI) / 180;
  const p2 = Math.asin(Math.sin(p1) * Math.cos(d) + Math.cos(p1) * Math.sin(d) * Math.cos(b));
  const l2 = (lon * Math.PI) / 180 + Math.atan2(Math.sin(b) * Math.sin(d) * Math.cos(p1), Math.cos(d) - Math.sin(p1) * Math.sin(p2));
  return [(p2 * 180) / Math.PI, (((l2 * 180) / Math.PI + 540) % 360) - 180];
}

function distNm(lat1: number, lon1: number, lat2: number, lon2: number) {
  const r = Math.PI / 180;
  const a = Math.sin(((lat2 - lat1) * r) / 2) ** 2 + Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin(((lon2 - lon1) * r) / 2) ** 2;
  return 2 * R_NM * Math.asin(Math.min(1, Math.sqrt(a)));
}

/** Distance from your aircraft when the sim is running; otherwise from the map's centre (what the bridge measured). */
let ownPos: { lat: number; lon: number } | null = null;
const away = (p: NetPilot) => (ownPos ? distNm(ownPos.lat, ownPos.lon, p.lat, p.lon) : p.distNm);

function pilotPopup(p: NetPilot) {
  const route = p.dep || p.arr ? `${esc(p.dep ?? "?")} → ${esc(p.arr ?? "?")}` : "No flight plan";
  return `<div class="pop"><b>${esc(p.callsign)}</b>${p.type ? ` <span class="pop__muted">${esc(p.type)}</span>` : ""}<br>${route}<br>${int(p.alt)} ft · ${int(p.gs)} kt · ${hdg(p.hdg)}°<br><span class="pop__muted">${int(away(p))} nm ${ownPos ? "from you" : "from map centre"}</span></div>`;
}
function stationLines(list: AtcStation[]) {
  return list
    .map((s) => `<div><b>${esc(s.freq)}</b> ${esc(s.name)} <span class="pop__muted">${esc(s.callsign)}</span>${s.atisCode ? ` <span class="pop__muted">ATIS ${esc(s.atisCode)}</span>` : ""}</div>`)
    .join("");
}

function loadView(): { center: [number, number]; zoom: number } | null {
  try {
    const v = JSON.parse(localStorage.getItem(VIEW_KEY) ?? "null");
    return v && Array.isArray(v.center) && typeof v.zoom === "number" ? v : null;
  } catch {
    return null;
  }
}
function saveView(map: L.Map) {
  try {
    const c = map.getCenter();
    localStorage.setItem(VIEW_KEY, JSON.stringify({ center: [c.lat, c.lng], zoom: map.getZoom() }));
  } catch {
    /* not important */
  }
}

/** Boundary shapes already fetched from the bridge, by id. Kept across tab switches. */
const shapes = new Map<string, GeoJSON.Feature>();

interface Layers {
  own: L.Marker | null;
  track: L.Polyline;
  traffic: L.LayerGroup;
  sectors: L.LayerGroup;
  labels: L.LayerGroup;
  airports: L.LayerGroup;
}

export default function MapView({ b }: { b: BridgeSnapshot }) {
  const { setTrafficArea } = useBridgeActions();
  const el = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const lay = useRef<Layers | null>(null);
  const [follow, setFollow] = useState(true);
  const followRef = useRef(follow);
  followRef.current = follow;
  const [shapesVersion, setShapesVersion] = useState(0);
  const trafficMarks = useRef(new Map<string, { m: L.Marker; p: NetPilot }>());
  const trafficAt = useRef(0);
  const [selected, setSelected] = useState<string | null>(null);

  const lastArea = useRef<{ c: L.LatLng; r: number } | null>(null);
  /** Tells the bridge where the map is, unless it has barely moved since last time. */
  const sendArea = useCallback(() => {
    const map = mapRef.current;
    if (!map) return;
    const c = map.getCenter();
    const r = Math.min(1000, Math.max(20, (c.distanceTo(map.getBounds().getNorthEast()) / 1852) * 1.1));
    const last = lastArea.current;
    if (last && c.distanceTo(last.c) / 1852 < last.r * 0.15 && Math.abs(r - last.r) / last.r < 0.15) return;
    lastArea.current = { c, r };
    setTrafficArea(c.lat, c.lng, r);
  }, [setTrafficArea]);

  /* ---- create the map once ---- */
  useEffect(() => {
    const t = b.latest?.data;
    const saved = loadView();
    const map = L.map(el.current!, {
      zoomControl: false,
      worldCopyJump: true,
      preferCanvas: false,
      center: t ? [t.lat, t.lon] : (saved?.center ?? [20, 0]),
      zoom: t ? Math.max(saved?.zoom ?? 8, 6) : (saved?.zoom ?? 3),
    });
    mapRef.current = map;
    L.control.zoom({ position: "topright" }).addTo(map);
    map.attributionControl.setPrefix('<a href="https://leafletjs.com">Leaflet</a>');
    map.attributionControl.addAttribution(DATA_ATTR);
    L.tileLayer(TILES, { attribution: TILE_ATTR, maxNativeZoom: 16, maxZoom: 18 }).addTo(map);
    // Place names above the aircraft-free ground, below markers.
    map.createPane("basemapLabels").style.zIndex = "250";
    L.tileLayer(TILES_LABELS, { pane: "basemapLabels", maxNativeZoom: 16, maxZoom: 18, opacity: 0.9 }).addTo(map);

    const layers: Layers = {
      own: null,
      track: L.polyline(
        track.points().map((p) => [p[0], p[1]] as [number, number]),
        { color: "#4fd1a5", weight: 2, opacity: 0.9, interactive: false },
      ).addTo(map),
      sectors: L.layerGroup().addTo(map),
      labels: L.layerGroup().addTo(map),
      airports: L.layerGroup().addTo(map),
      traffic: L.layerGroup().addTo(map),
    };
    lay.current = layers;

    const zoomClass = () => {
      el.current?.classList.toggle("map--labels", map.getZoom() >= LABEL_ZOOM);
      el.current?.classList.toggle("map--sector-labels", map.getZoom() >= SECTOR_LABEL_ZOOM);
    };
    zoomClass();
    let areaTimer = 0;
    map.on("zoomend", zoomClass);
    map.on("dragstart", () => setFollow(false));
    map.on("moveend", () => {
      saveView(map);
      // Throttled, not debounced: while following the aircraft the map never stops moving.
      if (!areaTimer)
        areaTimer = window.setTimeout(() => {
          areaTimer = 0;
          sendArea();
        }, 700);
    });
    sendArea();
    // The container may still be settling its size on first paint.
    const sizeTimer = setTimeout(() => map.invalidateSize(), 100);

    const unsub = track.subscribe((added, reset) => {
      if (reset) layers.track.setLatLngs(track.points().map((p) => [p[0], p[1]] as [number, number]));
      else for (const p of added as TrackPoint[]) layers.track.addLatLng([p[0], p[1]]);
    });

    return () => {
      unsub();
      clearTimeout(areaTimer);
      clearTimeout(sizeTimer);
      trafficMarks.current.clear();
      map.remove();
      mapRef.current = null;
      lay.current = null;
    };
  }, [sendArea]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (b.sessionId) void track.loadHistory(b.sessionId);
  }, [b.sessionId]);

  /* ---- own aircraft ---- */
  const t = b.latest?.data;
  ownPos = t ? { lat: t.lat, lon: t.lon } : null;
  useEffect(() => {
    const map = mapRef.current;
    const layers = lay.current;
    if (!map || !layers || !t) return;
    if (!layers.own) {
      layers.own = L.marker([t.lat, t.lon], { icon: planeIcon("ac--own", 30), keyboard: false, zIndexOffset: 1000, interactive: false }).addTo(map);
    } else layers.own.setLatLng([t.lat, t.lon]);
    rotate(layers.own, t.hdgTrue);
    if (followRef.current) map.panTo([t.lat, t.lon], { animate: true, duration: 0.25, noMoveStart: true });
  }, [t]);

  useEffect(() => {
    const map = mapRef.current;
    if (follow && map && t) map.setView([t.lat, t.lon], Math.max(map.getZoom(), 7));
  }, [follow]); // eslint-disable-line react-hooks/exhaustive-deps

  /* ---- traffic ---- */
  useEffect(() => {
    const layers = lay.current;
    if (!layers) return;
    const pilots = b.traffic?.pilots ?? [];
    const marks = trafficMarks.current;
    const keep = new Set<string>();
    for (const p of pilots) {
      keep.add(p.callsign);
      const cur = marks.get(p.callsign);
      if (cur) {
        cur.p = p;
        cur.m.setLatLng([p.lat, p.lon]);
        cur.m.setPopupContent(pilotPopup(p));
      } else {
        const m = L.marker([p.lat, p.lon], { icon: planeIcon("ac--traffic", 18, p.callsign), keyboard: false, title: p.callsign })
          .bindPopup(pilotPopup(p), { closeButton: false, autoPan: false })
          .on("popupopen", () => setSelected(p.callsign))
          .on("popupclose", () => setSelected((s) => (s === p.callsign ? null : s)))
          .addTo(layers.traffic);
        marks.set(p.callsign, { m, p });
      }
      rotate(marks.get(p.callsign)!.m, p.hdg);
    }
    for (const [cs, { m }] of marks) {
      if (!keep.has(cs)) {
        layers.traffic.removeLayer(m);
        marks.delete(cs);
      }
    }
    trafficAt.current = b.traffic?.receivedAt ?? 0;
  }, [b.traffic]);

  // Between network updates (every 15 s), move traffic along its heading so it doesn't jump.
  useEffect(() => {
    const id = setInterval(() => {
      const age = Math.min(EXTRAPOLATE_MAX_S, (Date.now() - trafficAt.current) / 1000);
      if (age <= 0) return;
      for (const { m, p } of trafficMarks.current.values()) {
        if (p.gs < 40) continue;
        m.setLatLng(project(p.lat, p.lon, p.hdg, (p.gs * age) / 3600));
      }
    }, 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    for (const [cs, { m }] of trafficMarks.current) m.getElement()?.querySelector(".ac")?.classList.toggle("ac--sel", cs === selected);
  }, [selected, b.traffic]);

  /* ---- ATC sectors and airports ---- */
  useEffect(() => {
    const missing = [...new Set(b.stations.map((s) => s.boundaryId).filter((id): id is string => !!id && !shapes.has(id)))];
    if (!missing.length || b.link !== "open") return;
    let cancelled = false;
    void (async () => {
      try {
        for (let i = 0; i < missing.length; i += 100) {
          const res = await apiFetch(`/api/network/boundaries?ids=${encodeURIComponent(missing.slice(i, i + 100).join(","))}`);
          if (!res.ok) return;
          const fc = (await res.json()) as GeoJSON.FeatureCollection;
          for (const f of fc.features) shapes.set(String(f.properties?.id), f);
        }
        if (!cancelled) setShapesVersion((v) => v + 1);
      } catch {
        /* try again on the next station update */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [b.stations, b.link]);

  const currentCs = b.atc?.current?.callsign ?? null;
  useEffect(() => {
    const layers = lay.current;
    if (!layers) return;
    layers.sectors.clearLayers();
    layers.labels.clearLayers();
    layers.airports.clearLayers();

    // Bigger areas first so smaller ones stay clickable on top.
    const withShape = b.stations.filter((s) => s.boundaryId && shapes.has(s.boundaryId));
    const byShape = new Map<string, AtcStation[]>();
    for (const s of withShape) byShape.set(s.boundaryId!, [...(byShape.get(s.boundaryId!) ?? []), s]);
    const order = [...byShape.entries()].sort(([, a], [, b2]) => (a[0]!.facility === "ctr" || a[0]!.facility === "fss" ? 0 : 1) - (b2[0]!.facility === "ctr" || b2[0]!.facility === "fss" ? 0 : 1));
    for (const [id, list] of order) {
      const f = list[0]!.facility as keyof typeof COLORS;
      const isCur = list.some((s) => s.callsign === currentCs);
      const color = COLORS[f] ?? COLORS.ctr;
      L.geoJSON(shapes.get(id)!, {
        style: { color, weight: isCur ? 3 : 1.2, opacity: isCur ? 1 : 0.75, fillColor: color, fillOpacity: isCur ? 0.14 : 0.04 },
      })
        .bindTooltip(`<div class="pop">${stationLines(list)}</div>`, { sticky: true, direction: "top", opacity: 1 })
        .addTo(layers.sectors);
    }

    // Sector labels for centres (callsign + frequency at the sector's label point).
    for (const s of b.stations) {
      if ((s.facility !== "ctr" && s.facility !== "fss") || s.lat === null || s.lon === null) continue;
      L.marker([s.lat, s.lon], {
        interactive: false,
        keyboard: false,
        icon: L.divIcon({ className: "seclabel-wrap", iconSize: [0, 0], html: `<div class="seclabel${s.callsign === currentCs ? " seclabel--cur" : ""}">${esc(s.callsign)}<br><b>${esc(s.freq)}</b></div>` }),
      }).addTo(layers.labels);
    }

    // Airports: one badge per airport with a letter per online position.
    const apts = new Map<string, { lat: number; lon: number; icao: string; list: AtcStation[] }>();
    for (const s of b.stations) {
      if (s.facility === "ctr" || s.facility === "fss" || s.lat === null || s.lon === null) continue;
      const key = `${s.lat.toFixed(3)},${s.lon.toFixed(3)}`;
      const a = apts.get(key) ?? { lat: s.lat, lon: s.lon, icao: s.callsign.split("_")[0]!, list: [] };
      a.list.push(s);
      apts.set(key, a);
    }
    const LETTER: Record<string, string> = { del: "D", gnd: "G", twr: "T", app: "A" };
    for (const a of apts.values()) {
      const letters = ["del", "gnd", "twr", "app"].filter((f) => a.list.some((s) => s.facility === f));
      const cur = a.list.some((s) => s.callsign === currentCs);
      const atis = a.list.find((s) => s.atisCode);
      L.marker([a.lat, a.lon], {
        keyboard: false,
        title: a.icao,
        icon: L.divIcon({
          className: "apt-wrap",
          iconSize: [0, 0],
          html: `<div class="apt${cur ? " apt--cur" : ""}"><b>${esc(a.icao)}</b>${letters.map((f) => `<span class="apt__f apt__f--${f}">${LETTER[f]}</span>`).join("")}${atis ? `<span class="apt__f apt__f--atis">${esc(atis.atisCode!)}</span>` : ""}</div>`,
        }),
      })
        .bindPopup(`<div class="pop">${stationLines(a.list)}${atis?.atis?.length ? `<div class="pop__atis">${esc(atis.atis.join(" "))}</div>` : ""}</div>`, { closeButton: false, maxWidth: 300 })
        .addTo(layers.airports);
    }
  }, [b.stations, shapesVersion, currentCs]);

  const nearby = (b.traffic?.pilots ?? [])
    .map((p) => ({ p, d: away(p) }))
    .sort((a, c) => a.d - c.d)
    .slice(0, 12);

  return (
    <div className="mapview">
      <div className="map-shell">
        <div ref={el} className="map" role="application" aria-label="Moving map with your aircraft, network traffic and online ATC" />
        <div className="map-overlay map-overlay--top">
          <NetworkChip b={b} />
          {t && (
            <button type="button" className={`btn btn--map${follow ? " is-on" : ""}`} aria-pressed={follow} onClick={() => setFollow(!follow)}>
              {follow ? "Following" : "Follow aircraft"}
            </button>
          )}
        </div>
      </div>
      <AtcCard b={b} />
      {nearby.length > 0 && (
        <section className="card">
          <h2 className="card__title">Nearest traffic{t ? "" : " (to the map centre)"}</h2>
          <table className="tbl">
            <thead>
              <tr>
                <th scope="col">Callsign</th>
                <th scope="col">Type</th>
                <th scope="col">Route</th>
                <th scope="col" className="num">Alt ft</th>
                <th scope="col" className="num">nm</th>
              </tr>
            </thead>
            <tbody>
              {nearby.map(({ p, d }) => (
                <tr key={p.callsign} className={p.callsign === selected ? "is-sel" : undefined}>
                  <td>
                    <button
                      type="button"
                      className="linkish"
                      onClick={() => {
                        setFollow(false);
                        const m = trafficMarks.current.get(p.callsign)?.m;
                        if (m && mapRef.current) {
                          mapRef.current.setView(m.getLatLng(), Math.max(mapRef.current.getZoom(), 8));
                          m.openPopup();
                        }
                      }}
                    >
                      {p.callsign}
                    </button>
                  </td>
                  <td>{p.type ?? "—"}</td>
                  <td>{p.dep || p.arr ? `${p.dep ?? "?"}–${p.arr ?? "?"}` : "—"}</td>
                  <td className="num">{int(p.alt)}</td>
                  <td className="num">{int(d)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )}
    </div>
  );
}
