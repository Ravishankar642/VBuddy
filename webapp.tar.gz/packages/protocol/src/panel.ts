import { z } from "zod";

/** Which cockpit layout suits the loaded aircraft. */
export const FamilySchema = z.enum(["airbus", "boeing", "other"]);
export type Family = z.infer<typeof FamilySchema>;

export const LIGHT_IDS = ["nav", "beacon", "strobe", "landing", "taxi", "wing", "logo", "recognition", "cabin", "panel"] as const;
export const LightIdSchema = z.enum(LIGHT_IDS);
export type LightId = z.infer<typeof LightIdSchema>;

/** Boeing MCP / generic autopilot buttons. Each presses like the real button (toggles). */
export const ApButtonSchema = z.enum(["cmd", "fd", "athr", "speed", "lvlChg", "hdgSel", "lnav", "app", "altHld", "vs"]);
export type ApButton = z.infer<typeof ApButtonSchema>;

export const ApKnobSchema = z.enum(["spd", "hdg", "alt", "vs", "crs"]);
export type ApKnob = z.infer<typeof ApKnobSchema>;

export const PanelCommandSchema = z.discriminatedUnion("op", [
  /** Switch an exterior/interior light on or off. */
  z.object({ op: z.literal("light"), id: LightIdSchema, on: z.boolean() }),
  /** Press an autopilot button. */
  z.object({ op: z.literal("press"), ctl: ApButtonSchema }),
  /** Turn a knob by detents (+ = clockwise): 1 kt/Mach 0.01, 1 deg, 100 ft, 100 fpm. */
  z.object({ op: z.literal("turn"), ctl: ApKnobSchema, steps: z.number().int().min(-60).max(60).refine((n) => n !== 0) }),
  /** Dial a window to an exact value. */
  z.object({ op: z.literal("set"), ctl: ApKnobSchema, value: z.number().min(-10000).max(60000) }),
]);
export type PanelCommand = z.infer<typeof PanelCommandSchema>;

export const PanelStateSchema = z.object({
  /** Aircraft title as the simulator reports it ("" until known). */
  aircraft: z.string(),
  family: FamilySchema,
  /** Lights as the simulator reports them (true = on). */
  lights: z.record(LightIdSchema, z.boolean()),
  /** Autopilot as the simulator reports it, or null when it isn't reporting. */
  ap: z
    .object({
      master: z.boolean(),
      fd: z.boolean(),
      athr: z.boolean(),
      speed: z.boolean(),
      lvlChg: z.boolean(),
      hdgSel: z.boolean(),
      lnav: z.boolean(),
      app: z.boolean(),
      altHld: z.boolean(),
      vs: z.boolean(),
      /** Selected values. spd is knots, or Mach when machMode. */
      spd: z.number(),
      machMode: z.boolean(),
      hdg: z.number(),
      alt: z.number(),
      vsFpm: z.number(),
      crs: z.number(),
    })
    .nullable(),
  /** Short note for the pilot, e.g. "this aircraft ignored the last command". */
  note: z.string().nullable(),
});
export type PanelState = z.infer<typeof PanelStateSchema>;

/** Which family an aircraft title belongs to. Add-on titles are matched by name, so unknown ones fall to "other". */
export function familyOf(title: string, model = ""): Family {
  const t = `${title} ${model}`.toLowerCase();
  if (/fenix|fnx|fslabs|\ba3[1-9]\d|airbus|a32nx|a3[0-9]{2}\b|inibuilds.*a3/.test(t)) return "airbus";
  if (/pmdg|ifly|\b7[0-9]7\b|\b73[0-9]\b|\b74[0-9]\b|\b75[0-9]\b|\b76[0-9]\b|\b77[0-9]\b|\b78[0-9]\b|boeing|b7[0-9]{2}|b73[0-9]/.test(t)) return "boeing";
  return "other";
}
