# Changelog

## 2.2.0 (v3 preview)

- **Profile and fuel (Live page).** A new section for flights with a matching SimBrief plan:
  - **Vertical profile chart:** the plan's climb, cruise and descent, the top of descent, and where you are on it.
  - **Altitude against the plan:** the planned altitude here and how far above or below it you are. On the descent you're flagged high or low when more than 1,000 ft off.
  - **Distance to the top of descent,** and the next fix.
  - **Fuel against the plan:** fuel now vs what SimBrief planned at this point, and the fuel you'll land with at this rate.
- **Fuel alerts:** a notification when you're heading for a landing below reserve + alternate, and another if it drops into the final reserve.
- **Stabilised approach checks** at 1,000 ft and 500 ft above the ground on the way down: gear, flaps, sink rate (1,000 fpm at most), steady speed, bank and descent path (2–4°). Stable shows a note in the app; unstable sends an alert, and at 500 ft it suggests a go-around. Both gates appear in the landing report. They're checked twice a second from data VBuddy already reads, so they add nothing to the sim's load.
- **Wind ahead:** SimBrief's forecast wind for the rest of the route, as an average tailwind or headwind (Live → Profile and fuel).
- **Destination weather watch:** in flight, VBuddy checks the destination's METAR every 10 minutes. It alerts you when the weather gets worse (VFR → IFR and so on), when gusts reach 25 kt, or when thunderstorms are reported.
- **SIGMETs on the map:** thunderstorm, turbulence, icing and volcanic ash areas show whenever map weather is on. Tap one to read it. They're fetched only while a map shows weather, and kept 15 minutes.
- **Landing replay** (Logbook → a landing). Play back the last 20 seconds from above and from the side, with height, sink, speed, pitch, bank and G at each moment. Where VBuddy has the airport's runway layout, it also shows where you touched down: the runway, how far past the threshold, how far off the centreline, and how much runway was left. The replay is worked out on your phone; the bridge only adds position to the landing record.
- **Landing record** (Logbook → Overview): average and softest sink rate, landings by rating, your current and best run of landings rated normal or better, your last 10 landings against the 10 before, and averages per aircraft.
- **Badges** for things you've flown: first butter, 10/50/100 landings, runs of 5 and 20 good landings, a good crosswind landing, 5 stable approaches, 10 airports, an 8-hour flight.
- **Export** your landings or flights as CSV, or everything as JSON. On a phone it goes to the share sheet.
- **Share a landing** as a picture (the Share button on a landing): sink rate, rating, G, speed, pitch and wind, in your airline's colours.
- **Instructions picked out of ATC messages** (Comms → Messages): levels, altitudes, headings, speeds, frequencies, squawk, QNH and directs show as chips under each message, from typed text or voice to text. Tap a frequency to tune COM1, or a squawk to set the transponder.
- **Next controller, one tap:** Live → Airspace now has a "Tune COM1" button for the next station along your route.
- **Destination ATIS:** when an ATIS is online at your destination, Live → Airspace shows its letter, runways in use and QNH, with a "Tune COM2" button.
- **VATSIM events** at your departure or destination in the next 24 hours show in Live → Airspace (checked at most once an hour).
- **New look on phones:**
  - **Map:** one row along the top (status, notifications, settings) and three map buttons. Search, follow, and a map options menu holding map style, traffic, ATC and weather. Alerts are shorter.
  - **Flight card:** a phase card with the number that matters now (time to top of descent in cruise, time to landing on the way down), a route bar with your aircraft and the top of descent, four tiles (altitude, ground speed, vertical speed, landing fuel) and a "Next up" card to tune the next controller.
  - **Comms:** one row of tabs (Radio · Messages · ACARS · Traffic), and a "Latest for you" card with ATC's last call to you, its instructions as chips and the readback written out.
  - **Logbook:** a totals strip and your last 20 landings as a chart.
- **Approach mode:** below 2,000 ft with the gear down and descending, a focused screen opens by itself. It shows big radio height and sink rate, where you are against a 3° path, the stabilised-approach checks as they stand, and IAS, GS and altitude. It closes at touchdown, or with ✕. It's worked out on your phone.
- **Checklists** (Live → Checklists): before start through parking, in Airbus or Boeing style depending on the aircraft (a general one otherwise). The checklist for the moment is picked for you. Items the sim can confirm tick themselves (parking brake, engines, flaps, gear, transponder, autopilot). Ticks are kept on your phone for the flight.
- **Health** (Settings, top): the bridge, simulator, vPilot link, voice to text, relay, SimBrief, VATSIM data, updates and PC load, each with what to do when something is wrong. **Diagnostics file** saves the settings, what's connected and the bridge's recent log for a bug report, with pairing codes and links left out. Only this PC and paired devices can see it.
- **Settings follow you between devices:** theme, airline colours, map style and weather, chime, ATC auto-play, the Live page's open sections and checklist ticks are kept on the PC. A newly paired phone or tablet starts with them, and a checklist ticked on the tablet ticks on the phone. This works through the relay too. Pairing details and caches stay on each device.
- **Secure phone link (home-network edition):** the VBuddy window gets a "Secure phone link (https)" card. With Tailscale (free) on your PC and phone, one click (Set up) gives VBuddy an https address on your tailnet. Open VBuddy on your phone from that address and notifications work, without the cloud relay. Devices still need to be paired. Health shows whether it's set up.

## 2.1.6

- **Altitude now matches your altimeter.** The app showed true altitude, which in air warmer or colder than standard is over 1,000 ft off what the PFD shows in cruise. It now shows the altimeter's reading (with your baro setting), as do top of climb, the 10,000 ft events and the flight log's highest altitude. The map, traffic and landing data still use true altitude.

## 2.1.5

- **vPilot link reconnects by itself.** After the bridge restarted, the VBuddy Link plugin could keep believing it was still connected and never come back, so the bridge said "Plugin not connected" until vPilot was restarted. The bridge now sends the plugin a check-in every 10 s. VBuddy Link 1.0.1 reconnects when it hasn't heard one for 30 s.
- VBuddy Link no longer waits on vPilot's debug window while it writes its log, so a busy vPilot can't stall the connection.
- Update the plugin with the installer's "vPilot plugin" option. Restart vPilot once afterwards.

## 2.1.4

- **No more touchdown stutter from VBuddy.** Some reads still ran on every sim frame, even in Lite mode. They're now throttled too:
  - **Fenix FCU:** VBuddy read about 55 cockpit (L:) variables on every frame, which is the most expensive thing to ask the sim for. It now reads them every 6th frame (every 16th in Lite mode), and once a second while landing or with nobody looking. Knobs and lights on the phone still respond straight away.
  - **Radios and transponder:** read every 16th frame (every 46th in Lite mode), and once a second while landing or in the background.
- **Nothing touches the disk at touchdown.** During the landing, flight-log writes wait in memory, and the landing itself is saved once the roll-out is over. The touchdown report still appears in the app straight away. The "you landed" notification also waits until the roll-out is over (90 s at most).
- The touchdown report is encoded once for all screens instead of once per screen.

## 2.1.3

- **A lighter bridge.** VBuddy asks MSFS for much less. In cruise the flight data comes every 4th sim frame instead of every frame. The wind and touchdown values are no longer sent separately on every frame, and engine gauges are read about 6 times a second instead of 15.
- **Very light landings.** Landings used to make the sim stutter, so in the landing window (below 1,000 ft, and on the runway above 40 kt) VBuddy now asks the sim for every second frame instead of every frame. The touchdown rate comes from the sim's own touchdown reading, so it stays exact. Gauge reads pause, and transcribing ATC waits until you've slowed down (90 s at most). The calls aren't lost, just held.
- **Lite mode** (Settings → Performance on the PC in the app, or the VBuddy window): the least work for the PC while everything still works.
  - Fewer samples from the sim (every 8th frame in cruise, every 3rd while landing).
  - The app is updated twice a second.
  - Gauge reads are lighter and ATC coverage is checked every 6 s.
  - The speech engine runs on 2 cores.
- **Only the essentials in the tray.** With no app on screen and the VBuddy window closed or minimised, VBuddy only records the flight, analyses landings, and sends alerts and notifications. Gauge reads stop and the sim is sampled less often. Everything comes back as soon as you look again.
- **Turn ATC voice to text on or off from your phone** (Comms → Messages, or Settings). Off frees the PC's speech engine completely.
- **Smaller telemetry.** Each frame's numbers are rounded to what's useful (positions to about 10 cm), so frames are about a third smaller for the phone and the flight log, and quicker to send.
- **The flight log stays small.** Its write-ahead log is limited to 8 MB (it could grow past 100 MB), and the space freed by old telemetry is given back. A 138 MB log shrinks to about 50 MB the first time.
- **Voice to text uses less CPU and memory.**
  - The speech engine only looks at as much audio as each call needs, with at least 15 s for accuracy, instead of 30 s every time.
  - It makes at most two extra attempts on a hard call instead of five.
  - It unloads its model when no ATC app has been running for 2 minutes, and loads it again when one starts.
  - The audio helper is compiled once instead of every time it starts.

## 2.1.2

- **Voice to text: one message per transmission.** Calls that followed each other closely came out as one message. A transmission now ends as soon as the radio goes quiet after the push-to-talk is released. When the next station answers after a short gap at a clearly different loudness, its call is split off too. The pause before the end of a call is also shorter (0.65 s instead of 0.8 s).

## 2.1.1

- **Voice to text hears only the ATC apps.** By default VBuddy now captures only the sound of vPilot, xPilot, Altitude (IVAO), swift, SayIntentions.AI and BeyondATC, plus any program you add by name. The sim, music and everything else on the same headset are left out. "Everything on one output device" is still there as a choice. A SayIntentions or BeyondATC call that already arrived as text isn't transcribed a second time. Needs Windows 10 version 2004 or later.

## 2.1.0

- **Taxi guidance that follows you.** The route is now worked out on the PC, so every device shows the same one. On the Flights tab a banner at the top gives the next instruction ("Turn left onto N2 in 720 m"). Short notes pop up for each turn, crossing and hold short, and a notification reaches your phone when the app is closed. Leave the route and VBuddy re-plans it from where you are, and the route clears itself after takeoff or once you're parked. Turn the banner, the notes and the notification on or off under Notifications → Taxi.
- **Taxi routes straight from ATC.** When a controller gives you a taxi clearance, VBuddy plans the route on its own. It works with VATSIM text, voice to text, SayIntentions or BeyondATC.
- **Your own side of the radio.** Voice to text can also listen to your microphone, so your calls to ATC (on VATSIM through vPilot, or to an AI ATC app) show in Comms next to the controller's.
- **ATC is calling you.** When ATC says your callsign, you get an alert in the app and a notification on your phone. It has its own switch under Notifications, and it works off VATSIM too: the callsign can come from your SimBrief plan or from the sim's livery.
- **Hear ATC without pressing play.** Comms → Messages → *Hear ATC here* plays each transmission as it arrives on your phone or tablet: all of them, or only the calls for you.
- **Comms has three pages:** Radio, Messages and ACARS.
- **More speech models, and a recommendation.** You can now pick from every whisper.cpp model, including the quantized ones. The new default, **large-v3-turbo-q5_0** (547 MB), is close to the most accurate model at a fraction of its work, which helps with fast, clipped VATSIM radio. A new *CPU use* setting (light, balanced or fast) decides how many cores the engine takes. On light and balanced it runs below normal priority, so the sim keeps its frames.
- **Your airline without a flight plan.** With no VATSIM callsign or SimBrief plan, VBuddy works out your airline from the sim: the livery's airline and flight number ("IndiGo 612"), or an airline named in the aircraft's title. The app's colours, the logo and the callsign all follow it.
- **App colours follow the airline you're flying as.** That's your network callsign, else your SimBrief plan, else the sim. They used to follow the VATSIM callsign only.
- **About 120 more airlines** have colours and logos, including easyJet Europe and Switzerland, Ryanair UK, Buzz, Lauda, Malta Air, Wizz Air UK, Malta and Abu Dhabi, Discover, Marabu, Riyadh Air, SalamAir, Thai AirAsia, AirAsia X, HK Express, Air Busan, Air Seoul, ZIPAIR, Air Premia, QantasLink, GoJet, CommuteAir, Arajet, Cargojet and Polar.
- **Logbook: the SimBrief plan goes with the right flight.** A plan sometimes attached itself to a short fragment of a flight that the logbook hides, so the flight you actually flew had no plan. Your older flights are fixed once, automatically.
- **The SimBrief plan leaves the Flights tab once the flight is over:** parked at the gate with the engines off. A new plan loads for your next flight.
- **Sim view full screen works on iPhone and inside the VBuddy window.** Where the browser won't go full screen, the view fills the app instead, with a close button.

## 2.0.1

- **ATC voice to text: the speech engine downloads again.** whisper.cpp's newest release has no files, so VBuddy now takes the newest one that includes the Windows build.

## 2.0.0

- **Ground: taxi routes from your simulator's scenery.** A new Ground tab reads the airport's taxiways, runways, holding points and stands straight from MSFS (2020 and 2024, add-on airports too) and draws them on the map. Plan a route to a runway or a stand, optionally via the taxiways you were given; VBuddy says it the way ATC would and guides you along it (turn onto, hold short, cross). A taxi clearance heard on the radio or sent by text is offered there with one tap.
- **ATC to text.** Voice to text turns what ATC says on your radio into text in Comms, on the PC (whisper.cpp, downloaded once from the VBuddy window), with your callsign spotted however it's said; each call can be played back. SayIntentions.AI's conversation shows in Comms with a developer key, and BeyondATC's messages are read from its log (experimental).
- **MCDUs for the Fenix and the FlyByWire A32NX** (and Headwind A339X), next to the PMDG CDU: Systems → MCDU, both sides, every key, typing into the scratchpad.
- **MSFS 2020 and MSFS 2024** are told apart (the app shows which one), and both are supported side by side.

## 1.2.1

- **An iPhone and iPad app** (`ios/`), installed with SideStore, that connects through the cloud relay (scan the phone link QR code in the VBuddy window, or type its ID), so it works on mobile data too: VBuddy full screen, the screen kept on, screenshots saved to Photos through the share sheet, and links opening in Safari. Each release gets an unsigned `.ipa` and a SideStore source built by GitHub; see ios/README.md for setting up SideStore so the app refreshes itself without the PC.
- **Flights shows only your flight**, with nothing above it. My flights moved to the Logbook (the new name for Atlas), Traffic to Comms. Settings and notifications are round buttons floating at the top left of the map.
- **A photo of your aircraft**, as on a flight tracker: by registration from Planespotters.net (from REG/ in your VATSIM remarks, then SimBrief, then the sim), with the photographer's credit. Without a registration, or when it belongs to another airline, a photo of your airline's aircraft of that type from Wikimedia Commons. The aircraft row shows the type's full name (Boeing 787-8 Dreamliner).
- **The Live page is laid out like a flight tracker's flight card:** callsign with flight number and type, airline and logo; departure and arrival with a progress bar, time since takeoff and time to arrival; altitude and ground speed; the aircraft and its registration (from the sim); then sections that open and close: more information, altitude and vertical speed, speed, wind and temperature, airspace (ATC now and next), autopilot and aircraft, and the data source with squawk and position.

## 1.2.0

- **Flights start when you've spawned, not in the menu.** VBuddy now knows the simulator's menu, hangar, loading screen and replays from flying (the camera state, the "Sim" event, MSFS's placeholder positions, and a position that doesn't move at speed). A flight starts once the aircraft has settled where it was put; a jump of more than 20 nm starts a new one. Replays no longer count as landings and no longer move the end of the flight, and a "flight" that never went anywhere is left out of the list.
- **Older flight records are tidied once:** flights that began at the menu placeholder (0°N 90°E) or in the MSFS 2024 hangar get their real start where the telemetry is still there, replayed landings are set aside (not deleted), and menu stretches are hidden. Flights flown on their SimBrief plan now show up in the Atlas.
- **The SimBrief plan is loaded when you connect to VATSIM**, and again when a flight starts and every couple of minutes until takeoff. It's tied to the flight only if it starts where the flight began, and the record keeps its callsign, route, planned distance and time (shown next to what you flew).
- **The map trail starts once you've spawned and connected to VATSIM** (straight away when vPilot isn't linked to VBuddy), belongs to the flight in progress, and starts again for a new flight. Your SimBrief route is drawn as a dashed line.
- **Weather on the map:** rain radar from RainViewer, and clouds from OpenWeatherMap with a free key pasted into the VBuddy window (the key stays on the PC; the PC fetches the tiles).
- **Notifications have their own page** (the bell), with a main switch and new options: takeoff, top of climb, passing 10,000 ft, approaching the destination, at the gate, flight plan loaded, the simulator stopping mid-flight, and the simulator pausing itself. In the app they show as short notes.
- **Notifications fixed on iPhone:** a push that arrived while the app was open wasn't shown, and Safari takes the permission away from a site after a few of those. Pushes are now always shown, and the bridge doesn't send them to a device that has the app on screen. A phone paired again is linked to its notifications by itself, devices that are no longer paired are dropped, and every notification sent is logged.
- **Airline colours:** connect to VATSIM as QTR123 and the app turns Qatar burgundy, IGO… IndiGo blue and white, UAE… Emirates green, white and black, and so on for about 260 airlines (flag carriers, low-cost, regional and cargo), in light and dark mode. A nameplate on the Live page shows the airline's logo, callsign, plan and distance to go. Logos come from a public airline-logo service; your own in %APPDATA%\VBuddy\logos (QTR.png) come first. Switch it off under Settings → Appearance.
- **Screenshots:** Systems → Sim view → *Take screenshot* grabs the sim window at full size, keeps it on the PC (%APPDATA%\VBuddy\screenshots) and saves it to your phone.
- **Inbox is now Comms.**
- **The Live page no longer greys out while data is coming in:** it compared the PC's clock with the phone's, so a phone a few seconds off made it look stale.

## 1.1.1

- **PMDG 737 and 777 set themselves up.** VBuddy finds the aircraft in your Community and Official folders (also when they're linked from another drive) and copies its SDK header into %APPDATA%\VBuddy\sdk, and copies it again when an aircraft update changes it. It also adds the [SDK] lines that turn on PMDG's data and CDU screens (EnableDataBroadcast, EnableCDUBroadcast.0/.1, and .2 on the 777) to the aircraft's 737_Options.ini / 777_Options.ini, with a backup the first time. This runs when VBuddy starts and on every aircraft change, because PMDG makes a fresh options file when the aircraft is reinstalled or updated. When VBuddy has just turned the data on, the app says to reload the aircraft.

## 1.1.0

- **iniBuilds A340 / A350 / A380 get the Fenix-style FCU screen** under Controls (knobs, windows, push/pull, AP1/AP2, A/THR, LOC, APPR, SPD/MACH, HDG-V/S TRK-FPA, METRIC, FD), driven through the aircraft's input events. No EFIS column (its baro and ND aren't wired yet).
- **iniBuilds buttons and push/pull are pressed once:** VBuddy now reads where each button's input event rests and changes it once, instead of "1 then 0", which on buttons resting at 1 was a double press (APPR armed and disarmed again) and on others did nothing.
- **iniBuilds V/S window follows the aircraft:** the A350 keeps its V/S in one of the slot variables (AUTOPILOT VERTICAL HOLD VAR:1-3); VBuddy shows whichever one moves.

- **iniBuilds A340, A350 and A380 controls:** the FCU buttons (AP, FD, A/THR, LOC, APPR), knob turns and push/pull, and the exterior lights now go through the aircraft's own input events (AIRLINER_FCU_* / AIRLINER_MCU_* / AIRLINER_LIGHTS_EXT_*, as found in the aircraft scans) instead of the standard events these aircraft ignore. Which way and how far a knob moves per step is learned on first use by watching the window. The Airbus FCU in the app gains a LOC button.
- **The aircraft's input-event list is asked for again until it arrives:** right after an aircraft loads, SimConnect often refuses the list ("ERROR ... list of the aircraft's input events" in the log), and VBuddy never asked again, so input-event aircraft (iniBuilds, iFly) got no controls.

- **PMDG 737 and 777 CDU in the app (Systems → CDU):** the CDU screen as the aircraft draws it (colours, small font, reverse video), the line select keys beside their lines, the function keys, numbers and letters, the EXEC light and MSG/OFST/FAIL/CALL (DSPY on the 777) lights. Left and right CDU (and centre on the 777). Type into the scratchpad from the phone keyboard, or a computer keyboard (Backspace = CLR, Enter = EXEC). Read the way PMDG's own CDU sample reads it; keys are pressed and released like PMDG's sample presses a switch. Needs `EnableCDUBroadcast.0=1` and `.1=1` (and `.2=1` on the 777) under [SDK] in the aircraft's options .ini; the app says so if they're missing.

- **Airbus aircraft get an Airbus FCU in Controls:** SPD/MACH, HDG, ALT and V/S windows with push/pull, and FD, AP, A/THR and APPR buttons, instead of the Boeing MCP buttons. No course window on an Airbus or on the PMDG 777 (neither has a course knob).
- **Study airliners say plainly that they can't be operated from outside:** the FSLabs A321neo (and ToLiss, iniBuilds A300/A310) keep their cockpit private; Cobalt can't operate them either. Their autopilot and light controls are switched off with that explanation, while the simulator controls (pause, view, flaps etc.) stay available.

- **PMDG MCP windows are set directly:** speed, Mach, heading, altitude, vertical speed and course now use the SDK's own "set" events (EVT_MCP_HDG_SET and friends), so the value lands exactly where it was asked instead of overshooting or creeping back. Turning the knob is kept as a fallback, and it now waits for the aircraft's data to catch up before counting clicks.

- **PMDG knobs and buttons click the way PMDG's sample does:** MCP knobs now turn with the mouse wheel (as PMDG_NG3_ConnectionTest.cpp slews the heading selector) and buttons send the press and then the release. VBuddy also finds the SDK files in the source folder's `sdk` folder, and when it can't find them the app says to copy them into %APPDATA%\VBuddy\sdk.

- **PMDG 737 / 777 controls follow PMDG's own SDK sample:** events are now sent the way PMDG_NG3_ConnectionTest.cpp sends them ("#<event number>" at the highest priority with GROUPID_IS_PRIORITY), instead of writing PMDG's control area without waiting for it to clear (which could lose knob clicks). The aircraft's data is read as one block, as in PMDG's sample. The simulator's standard events are sent at the highest priority too (as PMDG's sample and Cobalt do). The 737's landing lights (L/R RETRACT and FIXED) are found, the 777's missing course knob is no longer reported (it has none), and VBuddy also looks for the SDK files in %APPDATA%\VBuddy\sdk.

## 1.0.0
First release.

- **More aircraft controls from Cobalt** (second pass, every control function in Cobalt Bridge 1.2.5 listed with REA and compared):
  - Airbus FCU knobs can be pushed (managed) and pulled (selected) from the autopilot panel: FlyByWire with its own FCU events, the default A320neo with the simulator's slot-index events, the Fenix with its knob counters; each is checked against the managed dot.
  - FlyByWire: AP1, A/THR, LOC and APPR lights and the managed dots are read from FlyByWire's own FCU (it doesn't copy them into the standard variables), so buttons now confirm properly.
  - Setting speed, heading or V/S first selects the knob (as Cobalt does), so an Airbus in managed mode accepts the new value.
  - Negative values (V/S -1500) are sent the way SimConnect expects; before, they could fail to send.

- **Aircraft controls work the way Cobalt's do** (taken from Cobalt Bridge 1.2.5's own control tables, nothing invented):
  - Fenix A320: lights (beacon, strobe, nav/logo, landing, nose/taxi), seat belts, probe heat, parking brake, speed brake arm and APU (master, then START after 1.5 s) now move the Fenix's own overhead switches instead of the simulator's standard events, and the Systems page shows the Fenix's real switch positions. Each switch is read back to confirm it moved.
  - Fenix FCU: written directly through SimConnect first (MSFS 2020 SU12 and later, MSFS 2024), with MobiFlight only as the fallback for older simulator builds.
  - Fenix radios: COM frequencies are dialled on the Fenix radio panel itself (outer knob 1 MHz a click, inner knob one channel a click, 8.33 or 25 kHz spacing worked out from the first click), and transfer presses the panel's XFER key. The Fenix ignores the simulator's frequency events.
  - Aircraft are recognised in Cobalt's order; the default A320neo (Asobo and iniBuilds' version for MSFS 2024) uses the standard events; study airliners (iniBuilds A300/A310, ToLiss, FSLabs) now say plainly that values must be set on their FCU.
  - FlyByWire LVL CHG pushes the FCU altitude knob; iFly 737 MAX buttons use Cobalt's input-event names.
  - Engines can be started and stopped one at a time (fuel valve and starter) under Systems.
  None of this has been tried in the real simulator yet.

- **Automatic updates:** VBuddy checks for a new version when it starts and every 6 hours, downloads it in the background (but waits while the simulator is running, so it never competes with scenery streaming), checks the download against the release's SHA-256 list, and shows it under Settings → Updates in the VBuddy window with what's new. Install update asks Windows for permission, updates silently and starts VBuddy again. The home network edition gets the home network installer. Turn checks off with VBUDDY_NO_UPDATES=1. Updates come from the releases of github.com/Ravishankar642/Vbuddy-web. Based on how Cobalt's bridge updates itself.

- **ChasePlane views from your phone:** the Sim view page lists the views you saved in ChasePlane (your aircraft's views, and the airport views where you are) as buttons; tap one and the simulator switches to it. VBuddy talks to ChasePlane's own local connection on this PC (port 8652), the same way the open-source ComSpotter tool does (github.com/sw-jannik/comspotter, MIT), so there are no shortcuts to set up. Needs ChasePlane for MSFS 2024 running. Not yet tried with a real ChasePlane.

- **Live sim view (Systems → Sim view):** see the simulator window on your phone or tablet, about three pictures a second, at home or through the cloud relay, with the camera buttons (cockpit, outside, drone, look around, zoom) underneath. Works the way Cobalt's sim view does: the PC only captures while someone is watching, skips a picture if the previous one isn't finished, sends at most 1024 x 576 (JPEG quality 55), and drops pictures for a phone whose connection can't keep up instead of queueing them. Only this PC and paired devices can watch. Unlike Cobalt it never shows your whole screen when the simulator window isn't found; it says so instead. On mobile data it uses roughly 10-20 MB a minute. Not yet tried on a real MSFS window.

- **The installer opens the port by itself:** it always opens TCP 4789 in Windows Firewall for every network type (home Wi-Fi is often set to Public), allows VBuddy's own node.exe, and removes any earlier Block rule for it. The firewall tick box is gone.
- **Two editions of the installer:** `pnpm package:both` makes `VBuddy-Setup-<version>.exe` (with the Cloud relay switch for use away from home) and `VBuddy-Local-Setup-<version>.exe` (home network edition: no relay at all, the switch is hidden, the PC never connects to any VBuddy server, phones connect on the same Wi-Fi). Use `pnpm package:local` for the home edition alone. Installing one over the other switches editions and keeps your flights and settings.
- **Fenix EFB, full screen:** the full-screen EFB page has a "‹ VBuddy" button at the top left that returns to the app.

- **Fenix EFB inside VBuddy, at home and away:** Systems has a new EFB tab (and the PC window an EFB page) that shows the Fenix external EFB from your PC. VBuddy passes the EFB through its own address, so it works on your phone over the cloud relay as well, not only on your home network. It opens only on the PC and on paired devices. The EFB is looked for on port 8083 (change with `--efb-port` or `VBUDDY_EFB_PORT`). To use it away from home, update the relay on your cloud VM (the relay now also carries POST requests and binary data for the EFB; run deploy/relay/setup.sh again with the new relay build). Not yet tried against the real Fenix EFB, so some of its pages may need follow-up fixes.

- **New VBuddy window on the PC:** a sidebar with Connect (addresses, pairing code, cloud relay, paired devices), Live map, Flights, Systems, Atlas, Activity and Settings. Live map, Flights, Systems and Atlas are the app itself, inside the window. Activity lists what the bridge has been doing (with a problems-only filter). Settings has: reconnect to MSFS, pause the simulator later (at a time, or before top of descent, held on the PC), start VBuddy when you sign in to Windows, install or update the vPilot plugin, and your SimBrief and Hoppie details. The window opens larger (1180 x 780). Traffic planes on the map are bigger.

- **My flights and Atlas:** plan the flights you want to fly (from, to, aircraft, date, notes; change or delete them later, kept on your PC). Every flown flight now shows where it left from and arrived at, how far it went and how long it took; tap one to see its details and its route drawn on the map. Atlas totals your flights, hours, distance, airports and countries, lists the airports you have visited and the aircraft you fly most. Airports come from the bundled OurAirports list (public domain). Only flights flown on the route of a filled-in SimBrief plan are logged in the Atlas (the plan's departure and arrival must match where you actually took off and landed); other flights stay in My flights, marked as not logged. A flight's distance is worked out when it ends and kept, so totals stay right after the detailed route is cleared (telemetry is still kept for 24 hours by default).

- **Systems page reads every aircraft the way Cobalt does:** the same simulator variables, read in three groups (engines every few frames, autopilot, fuel, radios and the rest a few times a second, doors, warnings and weather once a second). The main engine gauge follows the engine type (N1 for jets, torque and propeller RPM for turboprops, RPM for pistons). Lights that only show in the aircraft's "lights on" states (many Airbus) now count, the squawk is decoded correctly, and the Fenix and FlyByWire read their FCU targets, managed dots, mode lights and switches from their own cockpit variables. New Overview with instruments and flight phase.

- **New app layout:** a full-screen map with a draggable bottom sheet and a floating tab bar (Flights, Systems, Inbox, Atlas, Search), a bridge status pill, round map buttons (appearance, traffic, ATC sectors, follow) and a settings button. On a tablet or PC the sheet is a side panel. Same burgundy look, light and dark.

- **Systems tab:** a live page of the aircraft: engines (N1, N2, EGT, fuel flow, oil, vibration), fuel, autopilot, surfaces, radios and squawk, electrical and hydraulics, pressurization, doors, lights, warnings and the weather around you. Read once a second from the simulator; values an aircraft does not report show a dash.

- **New look:** burgundy brand theme with **light and dark mode** (button in the top bar: same as device / light / dark; the map follows it). Flight tab redesigned around a hero card (altitude, airspeed, vertical speed, ground speed, heading dial); bottom tab bar on phones, side menu on tablets and desktops; Manrope and Barlow Condensed fonts are bundled, so it looks the same offline.

- **Brief tab:** your SimBrief flight plan (route, time, fuel, weights) and, for the departure, arrival and alternate airports, the current METAR (decoded: wind, visibility, cloud, temperature, QNH, VFR/MVFR/IFR/LIFR) and TAF. Look up any airport by ICAO code. Weather is cached for 5 minutes. Enter your SimBrief name or pilot ID, and (for the coming Hoppie messaging) your Hoppie logon code, in the **VBuddy window** on the PC; they are saved on the PC only and never go to the relay or a phone.

- **ACARS (Hoppie)** in the Comms tab: send telex, answer CPDLC messages (WILCO / UNABLE / STANDBY, AFFIRM / NEGATIVE, ROGER), request a pre-departure clearance filled in from your SimBrief plan, request METAR / TAF / ATIS, and request a CPDLC logon. The bridge checks for new messages about once a minute while the simulator is connected, and a new message is pushed to your devices if Messages notifications are on. Needs your Hoppie logon code (VBuddy window, Your accounts).
- **Fix (2):** the Fenix's AP1/AP2 lights now also switch the autopilot flag in the live data on the bridge, so every device shows "Autopilot on" without depending on the Cockpit data reaching the app.
- **Discovery tool:** type a label (for example `DIR`) and press Enter, then press that key in the cockpit; the report lists what changed under each label. For finding MCDU keys later.
- **Fix:** the Flight tab showed "Autopilot off" on the Fenix. It now also reads the Fenix's AP1/AP2 lights, shows an Autothrust chip, and takes the selected speed, heading, altitude and vertical speed from the Fenix FCU.
- **Simulator and systems card:** pause/resume, gear, spoilers, parking brake, engines, APU, pitot heat, seat belts, flaps, time rate, altimeter and camera, each checked against the simulator. **Pause later** at a set time or before the top of descent, kept on the PC.
- **iFly buttons and knobs:** buttons are now pressed and released (a momentary press), and a knob first tries the aircraft's own "set" control before stepping it up or down, with wider name matching.
- **PMDG 737 / 777 switched on:** driven from the aircraft's own SDK data (found in its package folder, or copied into the `sdk` folder). PMDG liveries titled without the maker name (for example "737-800 PAX BW SC") are now recognised. The discovery tool skips GSX and camera-tool variables and has `--lvar-filter`.
- **Autopilot controls for add-on aircraft:** the Cockpit tab now shows an autopilot panel for every aircraft, not only the Fenix. PMDG 737 knobs use PMDG's own SDK events, FlyByWire A32NX / A380X use its FCU events, and iFly 737 MAX uses its own input events. Each change is checked and reported honestly if the aircraft ignores it. PMDG buttons are still to come.
- **Top of descent notice:** a phone notification (5 to 30 minutes before, default 10; chosen per device) that the descent should start soon, worked out from your SimBrief plan and your ground speed.
- **Autopilot-off notice (optional):** tick "Autopilot switches off in the cruise" in the notification settings to get a phone notification and a banner if the autopilot drops out above 3,000 ft above ground after being on for 30 seconds or more. Off by default; separate from Aircraft alerts.
- **Aircraft alerts** (phone notification and a banner in the open app): engine stopped in flight, stall warning, overspeed, gear up while low and descending, high sink rate below 1,000 ft, and low fuel. The fuel warning time is chosen per device (15 to 90 minutes, or off); it is worked out from how fast the fuel has really been burning over the last few minutes.
- **Notification settings** per device: ATC boundary warning distance (10 to 150 nm), an optional hourly limit on boundary and no-ATC notices ("Contact" calls always come through), and a **VATSIM connected / disconnected** notice.

- **Bridge** for MSFS 2024 (SimConnect) with a built-in test flight; serves the web app on your network. Runs as a notification-area (tray) icon with Open, Copy address, Pairing code, Settings, Log, Start with Windows, Restart and Exit.
- **Flight** dashboard, **Map** with live VATSIM traffic and ATC boundary alerts, **Landings** log with touchdown rate, G, flare and bounces.
- **Cockpit**: Fenix A320 FCU and EFIS with split-touch knobs, lights card for every aircraft. Other Airbus: lights only. Cockpit controls are Airbus-only in this release.
- **Comms**: Zulu clock, VATSIM status, COM1/COM2 tuning and listen toggles, transponder, chat (radio, private, broadcast, SELCAL), unread badge and chime, via the **VBuddy Link** vPilot plugin. "Listen on this device" opens VATSIM Listen.
- **Pairing**: viewing is open on your network; controlling needs a code from the bridge PC.
- **VBuddy window** on the bridge PC (opens from the tray icon): simulator and vPilot status, phone address with QR code, pairing code, paired devices, and the cloud relay switch.
- **Away from home**: a shared cloud relay (https, `vbuddy.duckdns.org`) that anyone can switch on in the VBuddy window with no setup: each install makes its own id and key, so many PCs share one relay and nothing secret is built in. Phone link with QR code. Or host your own. Phone notifications for ATC, landings and chat.
- **Flight log** on disk with automatic catch-up after a dropped connection.
- Windows installer (bundles Node.js), portable zip, optional Start-with-Windows and firewall rule.
- Tools: `aircraft:discover` (find an aircraft's controls), `fenix:discover`, `pmdg:dump`.

Known limits: not yet tested end-to-end against a real MSFS 2024, vPilot or relay VM by the author's automated tests; IVAO is not included; PMDG, iniBuilds, iFly and FSLabs cockpit panels are not available yet (the PMDG code is present but switched off).
