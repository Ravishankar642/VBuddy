import { TELEPHONY } from "./telephony.js";
import { EXTRA } from "./airlines-extra.js";
/**
 * Airlines by ICAO code, with the colours the app takes on when you connect to VATSIM with one of their callsigns
 * (QTR123 = Qatar Airways). `brand` is the airline's main colour; `second` its second one (used for the planned
 * route on the map); `neutral` makes the surfaces plain black / white / grey instead of tinted with the brand colour.
 */
export interface Airline {
  name: string;
  iata: string;
  brand: string;
  second?: string;
  neutral?: boolean;
}

export const AIRLINES: Record<string, Airline> = {
  // Middle East
  QTR: { name: "Qatar Airways", iata: "QR", brand: "#5c0632", second: "#a7a9ac" },
  UAE: { name: "Emirates", iata: "EK", brand: "#00843d", second: "#d71921", neutral: true },
  ETD: { name: "Etihad Airways", iata: "EY", brand: "#8c6b2f", second: "#3b3b3b" },
  GFA: { name: "Gulf Air", iata: "GF", brand: "#7a1f3d", second: "#c8a45d" },
  OMA: { name: "Oman Air", iata: "WY", brand: "#00737a", second: "#c7a76c" },
  SVA: { name: "Saudia", iata: "SV", brand: "#006c4f", second: "#c9a227" },
  FDB: { name: "flydubai", iata: "FZ", brand: "#1b2a5b", second: "#f26722" },
  ABY: { name: "Air Arabia", iata: "G9", brand: "#d6003b", second: "#6d6e71" },
  KAC: { name: "Kuwait Airways", iata: "KU", brand: "#0b3b8c", second: "#3fa9f5" },
  RJA: { name: "Royal Jordanian", iata: "RJ", brand: "#2b2b2b", second: "#b8975a", neutral: true },
  MEA: { name: "Middle East Airlines", iata: "ME", brand: "#00703c", second: "#d71920" },
  ELY: { name: "El Al", iata: "LY", brand: "#003a8c", second: "#8fb3e0" },
  THY: { name: "Turkish Airlines", iata: "TK", brand: "#c8102e", second: "#5f6a72" },
  PGT: { name: "Pegasus", iata: "PC", brand: "#f9b000", second: "#6b1f6e" },
  // South Asia
  IGO: { name: "IndiGo", iata: "6E", brand: "#001b94", second: "#4f8dfd" },
  AIC: { name: "Air India", iata: "AI", brand: "#c8102e", second: "#4b0f2e" },
  AXB: { name: "Air India Express", iata: "IX", brand: "#e2521e", second: "#00757f" },
  VTI: { name: "Vistara", iata: "UK", brand: "#5f2a5f", second: "#c4a15a" },
  AKJ: { name: "Akasa Air", iata: "QP", brand: "#ff6d38", second: "#5b2a86" },
  SEJ: { name: "SpiceJet", iata: "SG", brand: "#d71920", second: "#f9a51b" },
  ALK: { name: "SriLankan Airlines", iata: "UL", brand: "#0b3b72", second: "#e5a823" },
  PIA: { name: "PIA", iata: "PK", brand: "#00664f", second: "#b3a369" },
  BBC: { name: "Biman Bangladesh", iata: "BG", brand: "#00704a", second: "#d1232a" },
  RNA: { name: "Nepal Airlines", iata: "RA", brand: "#c8102e", second: "#003893" },
  // East and South-East Asia, Oceania
  SIA: { name: "Singapore Airlines", iata: "SQ", brand: "#13284c", second: "#f0ab00" },
  CPA: { name: "Cathay Pacific", iata: "CX", brand: "#006564", second: "#a6a8ab" },
  JAL: { name: "Japan Airlines", iata: "JL", brand: "#c8102e", second: "#4d4d4d", neutral: true },
  ANA: { name: "All Nippon Airways", iata: "NH", brand: "#13448f", second: "#00a3e0" },
  KAL: { name: "Korean Air", iata: "KE", brand: "#00256c", second: "#4aa3df" },
  AAR: { name: "Asiana Airlines", iata: "OZ", brand: "#5c5c5c", second: "#c8102e", neutral: true },
  CCA: { name: "Air China", iata: "CA", brand: "#c8102e", second: "#4d4d4d" },
  CES: { name: "China Eastern", iata: "MU", brand: "#1d2a6b", second: "#e60012" },
  CSN: { name: "China Southern", iata: "CZ", brand: "#004a97", second: "#e60012" },
  HDA: { name: "Hong Kong Airlines", iata: "HX", brand: "#c8102e", second: "#9b8355" },
  EVA: { name: "EVA Air", iata: "BR", brand: "#00704a", second: "#f39200" },
  CAL: { name: "China Airlines", iata: "CI", brand: "#1d3c78", second: "#d4547b" },
  MAS: { name: "Malaysia Airlines", iata: "MH", brand: "#003a70", second: "#e2231a" },
  AXM: { name: "AirAsia", iata: "AK", brand: "#e2001a", second: "#5a5a5a" },
  THA: { name: "Thai Airways", iata: "TG", brand: "#4e2a84", second: "#c4007a" },
  GIA: { name: "Garuda Indonesia", iata: "GA", brand: "#00799c", second: "#8dc63f" },
  PAL: { name: "Philippine Airlines", iata: "PR", brand: "#00338d", second: "#e31837" },
  HVN: { name: "Vietnam Airlines", iata: "VN", brand: "#006885", second: "#c8a45d" },
  VJC: { name: "VietJet", iata: "VJ", brand: "#e21b22", second: "#fbd000" },
  QFA: { name: "Qantas", iata: "QF", brand: "#e0001b", second: "#5c5c5c" },
  VOZ: { name: "Virgin Australia", iata: "VA", brand: "#5b2c86", second: "#e31c24" },
  ANZ: { name: "Air New Zealand", iata: "NZ", brand: "#1a1a1a", second: "#00a6b6", neutral: true },
  // Europe
  BAW: { name: "British Airways", iata: "BA", brand: "#075aaa", second: "#eb2226" },
  VIR: { name: "Virgin Atlantic", iata: "VS", brand: "#da0530", second: "#5b2a6e" },
  EZY: { name: "easyJet", iata: "U2", brand: "#ff6600", second: "#4d4d4d" },
  RYR: { name: "Ryanair", iata: "FR", brand: "#073590", second: "#f1c933" },
  WZZ: { name: "Wizz Air", iata: "W6", brand: "#c6007e", second: "#2e2c8c" },
  DLH: { name: "Lufthansa", iata: "LH", brand: "#05164d", second: "#ffad00" },
  EWG: { name: "Eurowings", iata: "EW", brand: "#a5004a", second: "#7a7a7a" },
  SWR: { name: "Swiss", iata: "LX", brand: "#e2001a", second: "#5c5c5c", neutral: true },
  AUA: { name: "Austrian Airlines", iata: "OS", brand: "#e30613", second: "#5c5c5c", neutral: true },
  AFR: { name: "Air France", iata: "AF", brand: "#002157", second: "#e4002b" },
  KLM: { name: "KLM", iata: "KL", brand: "#00a1de", second: "#003082" },
  IBE: { name: "Iberia", iata: "IB", brand: "#d7192d", second: "#ffcc00" },
  VLG: { name: "Vueling", iata: "VY", brand: "#ffcc00", second: "#5a5a5a", neutral: true },
  TAP: { name: "TAP Air Portugal", iata: "TP", brand: "#e2001a", second: "#8dc63f" },
  ITY: { name: "ITA Airways", iata: "AZ", brand: "#1a3c8e", second: "#4cb8e8" },
  SAS: { name: "SAS", iata: "SK", brand: "#000a8c", second: "#a3a3a3" },
  FIN: { name: "Finnair", iata: "AY", brand: "#0b1560", second: "#5ac8fa" },
  NAX: { name: "Norwegian", iata: "DY", brand: "#d81939", second: "#003251" },
  ICE: { name: "Icelandair", iata: "FI", brand: "#002b5c", second: "#f3c300" },
  EIN: { name: "Aer Lingus", iata: "EI", brand: "#006272", second: "#8dc63f" },
  AEE: { name: "Aegean", iata: "A3", brand: "#0a3a7a", second: "#d4a017" },
  LOT: { name: "LOT Polish", iata: "LO", brand: "#11397e", second: "#a6a8ab" },
  CSA: { name: "Czech Airlines", iata: "OK", brand: "#004b93", second: "#d7141a" },
  BEL: { name: "Brussels Airlines", iata: "SN", brand: "#003d6b", second: "#e2001a" },
  CFG: { name: "Condor", iata: "DE", brand: "#f2b300", second: "#3b3b3b", neutral: true },
  AFL: { name: "Aeroflot", iata: "SU", brand: "#00256c", second: "#e31e24" },
  // Americas
  AAL: { name: "American Airlines", iata: "AA", brand: "#0078d2", second: "#c30019" },
  DAL: { name: "Delta", iata: "DL", brand: "#003a70", second: "#c8102e" },
  UAL: { name: "United", iata: "UA", brand: "#002244", second: "#0060a9" },
  SWA: { name: "Southwest", iata: "WN", brand: "#304cb2", second: "#ffbf27" },
  JBU: { name: "JetBlue", iata: "B6", brand: "#003876", second: "#0099d8" },
  ASA: { name: "Alaska Airlines", iata: "AS", brand: "#01426a", second: "#48a9c5" },
  FFT: { name: "Frontier", iata: "F9", brand: "#00704a", second: "#a6a6a6" },
  NKS: { name: "Spirit", iata: "NK", brand: "#ffd200", second: "#1a1a1a", neutral: true },
  HAL: { name: "Hawaiian", iata: "HA", brand: "#5b2a86", second: "#d6006d" },
  ACA: { name: "Air Canada", iata: "AC", brand: "#d22630", second: "#1a1a1a", neutral: true },
  WJA: { name: "WestJet", iata: "WS", brand: "#00a5b5", second: "#1c3f6e" },
  AMX: { name: "Aeroméxico", iata: "AM", brand: "#0b2343", second: "#e60f27" },
  VOI: { name: "Volaris", iata: "Y4", brand: "#a12f86", second: "#00a5b5" },
  LAN: { name: "LATAM", iata: "LA", brand: "#1b0088", second: "#ed1650" },
  TAM: { name: "LATAM Brasil", iata: "JJ", brand: "#1b0088", second: "#ed1650" },
  AVA: { name: "Avianca", iata: "AV", brand: "#da291c", second: "#4d4d4d" },
  CMP: { name: "Copa Airlines", iata: "CM", brand: "#00205b", second: "#9b8441" },
  GLO: { name: "GOL", iata: "G3", brand: "#ff7020", second: "#5c5c5c" },
  AZU: { name: "Azul", iata: "AD", brand: "#002f87", second: "#00a3e0" },
  ARG: { name: "Aerolíneas Argentinas", iata: "AR", brand: "#0a3f7a", second: "#68b6e5" },
  // Africa
  ETH: { name: "Ethiopian Airlines", iata: "ET", brand: "#2b7c3c", second: "#fcd116" },
  KQA: { name: "Kenya Airways", iata: "KQ", brand: "#c8102e", second: "#1a1a1a" },
  SAA: { name: "South African Airways", iata: "SA", brand: "#00335f", second: "#e2a225" },
  MSR: { name: "EgyptAir", iata: "MS", brand: "#0a2c5a", second: "#c8a24c" },
  RAM: { name: "Royal Air Maroc", iata: "AT", brand: "#c8102e", second: "#007a3d" },
  RWD: { name: "RwandAir", iata: "WB", brand: "#00a3e0", second: "#ffd100" },
};

/** More airlines (regional, low-cost, cargo and smaller flag carriers). */
const MORE: Record<string, Airline> = {
  // Middle East and Central Asia
  KNE: { name: "flynas", iata: "XY", brand: "#2c1e5e", second: "#00b2a9" },
  FAD: { name: "flyadeal", iata: "F3", brand: "#a6ce39", second: "#3a3a3a" },
  JZR: { name: "Jazeera Airways", iata: "J9", brand: "#00205b", second: "#e2a32f" },
  SAI: { name: "Salam Air", iata: "OV", brand: "#00a39b", second: "#f5a623" },
  IAW: { name: "Iraqi Airways", iata: "IA", brand: "#006a3a", second: "#c8102e" },
  IRA: { name: "Iran Air", iata: "IR", brand: "#00539b", second: "#c8102e" },
  SYR: { name: "Syrian Air", iata: "RB", brand: "#0a5c36", second: "#c8102e" },
  AZQ: { name: "Silk Way West", iata: "7L", brand: "#00205b", second: "#c8a45d" },
  AHY: { name: "Azerbaijan Airlines", iata: "J2", brand: "#00309a", second: "#e30a17" },
  KZR: { name: "Air Astana", iata: "KC", brand: "#7a5b2a", second: "#00a1de" },
  UZB: { name: "Uzbekistan Airways", iata: "HY", brand: "#0067b1", second: "#1eb53a" },
  AFG: { name: "Ariana Afghan", iata: "FG", brand: "#c8102e", second: "#007a3d" },
  // South Asia
  SQS: { name: "Star Air", iata: "S5", brand: "#00539b", second: "#f7a800" },
  LLR: { name: "Alliance Air", iata: "9I", brand: "#c8102e", second: "#0057a0" },
  FBA: { name: "Fly91", iata: "IC", brand: "#00a19a", second: "#f15a29" },
  UBG: { name: "US-Bangla Airlines", iata: "BS", brand: "#003e7e", second: "#e31e24" },
  NVQ: { name: "Novoair", iata: "VQ", brand: "#00539b", second: "#f7941d" },
  MLD: { name: "Maldivian", iata: "Q2", brand: "#e30613", second: "#00a3e0" },
  BTN: { name: "Drukair", iata: "KB", brand: "#f7a600", second: "#c8102e" },
  // East and South-East Asia
  CXA: { name: "XiamenAir", iata: "MF", brand: "#004a97", second: "#64b5e8" },
  CHH: { name: "Hainan Airlines", iata: "HU", brand: "#c8102e", second: "#d4a017" },
  CSZ: { name: "Shenzhen Airlines", iata: "ZH", brand: "#c8102e", second: "#5c5c5c" },
  CSC: { name: "Sichuan Airlines", iata: "3U", brand: "#00498f", second: "#c8102e" },
  CQH: { name: "Spring Airlines", iata: "9C", brand: "#00a651", second: "#3a3a3a" },
  CRK: { name: "HK Express", iata: "UO", brand: "#6a2c91", second: "#f7941d" },
  TTW: { name: "Tigerair Taiwan", iata: "IT", brand: "#f37021", second: "#3a3a3a" },
  SJX: { name: "STARLUX", iata: "JX", brand: "#4d3a2a", second: "#c8a45d" },
  JJP: { name: "Jetstar Japan", iata: "GK", brand: "#ff5115", second: "#1a1a1a" },
  APJ: { name: "Peach", iata: "MM", brand: "#c60c7f", second: "#7a7a7a" },
  SKY: { name: "Skymark", iata: "BC", brand: "#00539b", second: "#f7a600" },
  JTA: { name: "Japan Transocean Air", iata: "NU", brand: "#c8102e", second: "#00a3e0" },
  JNA: { name: "Jin Air", iata: "LJ", brand: "#4b1e78", second: "#78be20" },
  JJA: { name: "Jeju Air", iata: "7C", brand: "#f37021", second: "#3a3a3a" },
  TWB: { name: "T'way Air", iata: "TW", brand: "#c8102e", second: "#5c5c5c" },
  ABL: { name: "Air Busan", iata: "BX", brand: "#00539b", second: "#c8102e" },
  MGL: { name: "MIAT Mongolian", iata: "OM", brand: "#00519b", second: "#c8102e" },
  SLK: { name: "Silk Air", iata: "MI", brand: "#13284c", second: "#f0ab00" },
  TGW: { name: "Scoot", iata: "TR", brand: "#fdd000", second: "#1a1a1a", neutral: true },
  JSA: { name: "Jetstar Asia", iata: "3K", brand: "#ff5115", second: "#1a1a1a" },
  BTK: { name: "Batik Air", iata: "ID", brand: "#c8102e", second: "#d4a017" },
  LNI: { name: "Lion Air", iata: "JT", brand: "#c8102e", second: "#3a3a3a" },
  CTV: { name: "Citilink", iata: "QG", brand: "#00a651", second: "#3a3a3a" },
  AWQ: { name: "Indonesia AirAsia", iata: "QZ", brand: "#e2001a", second: "#5a5a5a" },
  APG: { name: "Philippines AirAsia", iata: "Z2", brand: "#e2001a", second: "#5a5a5a" },
  CEB: { name: "Cebu Pacific", iata: "5J", brand: "#ffd400", second: "#0067b1", neutral: true },
  BKP: { name: "Bangkok Airways", iata: "PG", brand: "#00539b", second: "#78be20" },
  TLM: { name: "Thai Lion Air", iata: "SL", brand: "#c8102e", second: "#3a3a3a" },
  NOK: { name: "Nok Air", iata: "DD", brand: "#ffd400", second: "#1a1a1a", neutral: true },
  TVJ: { name: "Thai Vietjet", iata: "VZ", brand: "#e21b22", second: "#fbd000" },
  BAV: { name: "Bamboo Airways", iata: "QH", brand: "#00704a", second: "#c8a45d" },
  MXD: { name: "Malindo / Batik Air Malaysia", iata: "OD", brand: "#c8102e", second: "#d4a017" },
  RBA: { name: "Royal Brunei", iata: "BI", brand: "#1a1a1a", second: "#c8a45d", neutral: true },
  MMA: { name: "Myanmar Airways Intl", iata: "8M", brand: "#00539b", second: "#d4a017" },
  KHV: { name: "Cambodia Angkor Air", iata: "K6", brand: "#00539b", second: "#c8102e" },
  LAO: { name: "Lao Airlines", iata: "QV", brand: "#00539b", second: "#c8102e" },
  // Oceania and the Pacific
  JST: { name: "Jetstar", iata: "JQ", brand: "#ff5115", second: "#1a1a1a" },
  RXA: { name: "Rex", iata: "ZL", brand: "#00539b", second: "#c8102e" },
  FJI: { name: "Fiji Airways", iata: "FJ", brand: "#1f3a5f", second: "#62b5e5" },
  ANG: { name: "Air Niugini", iata: "PX", brand: "#1a1a1a", second: "#c8102e", neutral: true },
  ACI: { name: "Aircalin", iata: "SB", brand: "#00539b", second: "#78be20" },
  THT: { name: "Air Tahiti Nui", iata: "TN", brand: "#003865", second: "#00a3ad" },
  // Europe
  TOM: { name: "TUI Airways", iata: "BY", brand: "#092a5e", second: "#e2001a" },
  TUI: { name: "TUIfly", iata: "X3", brand: "#092a5e", second: "#e2001a" },
  EXS: { name: "Jet2", iata: "LS", brand: "#c8102e", second: "#1a1a1a" },
  LOG: { name: "Loganair", iata: "LM", brand: "#003865", second: "#c8102e" },
  SHT: { name: "BA Shuttle", iata: "BA", brand: "#075aaa", second: "#eb2226" },
  CFE: { name: "BA CityFlyer", iata: "BA", brand: "#075aaa", second: "#eb2226" },
  CLH: { name: "Lufthansa CityLine", iata: "CL", brand: "#05164d", second: "#ffad00" },
  DLA: { name: "Air Dolomiti", iata: "EN", brand: "#003a70", second: "#ffad00" },
  DSM: { name: "Lufthansa City", iata: "VL", brand: "#05164d", second: "#ffad00" },
  EDW: { name: "Edelweiss", iata: "WK", brand: "#c8102e", second: "#5c5c5c", neutral: true },
  HOP: { name: "Air France Hop", iata: "A5", brand: "#002157", second: "#e4002b" },
  TVF: { name: "Transavia France", iata: "TO", brand: "#00d66c", second: "#1a1a1a" },
  TRA: { name: "Transavia", iata: "HV", brand: "#00d66c", second: "#1a1a1a" },
  KLC: { name: "KLM Cityhopper", iata: "WA", brand: "#00a1de", second: "#003082" },
  CXK: { name: "Corendon", iata: "XC", brand: "#c8102e", second: "#fdd000" },
  SXS: { name: "SunExpress", iata: "XQ", brand: "#003a70", second: "#fdb913" },
  AJA: { name: "AJet", iata: "VF", brand: "#00539b", second: "#c8102e" },
  ANE: { name: "Air Nostrum", iata: "YW", brand: "#c8102e", second: "#3a3a3a" },
  AEA: { name: "Air Europa", iata: "UX", brand: "#003a70", second: "#00a3e0" },
  IBS: { name: "Iberia Express", iata: "I2", brand: "#d7192d", second: "#ffcc00" },
  VOE: { name: "Volotea", iata: "V7", brand: "#e5006d", second: "#3a3a3a" },
  BCS: { name: "European Air Transport (DHL)", iata: "QY", brand: "#ffcc00", second: "#d40511", neutral: true },
  DHK: { name: "DHL Air", iata: "D0", brand: "#ffcc00", second: "#d40511", neutral: true },
  NOZ: { name: "Norwegian (NOZ)", iata: "DY", brand: "#d81939", second: "#003251" },
  NSZ: { name: "Norse Atlantic", iata: "N0", brand: "#0a2240", second: "#5ac8fa" },
  BRA: { name: "BRA", iata: "TF", brand: "#00a19a", second: "#3a3a3a" },
  WIF: { name: "Widerøe", iata: "WF", brand: "#00704a", second: "#1a1a1a" },
  FIA: { name: "Finnair (FIA)", iata: "AY", brand: "#0b1560", second: "#5ac8fa" },
  BTI: { name: "airBaltic", iata: "BT", brand: "#a6c339", second: "#3a3a3a" },
  LGL: { name: "Luxair", iata: "LG", brand: "#00a1de", second: "#003865" },
  ROT: { name: "TAROM", iata: "RO", brand: "#002b7f", second: "#ce1126" },
  BUC: { name: "Bulgaria Air", iata: "FB", brand: "#00539b", second: "#c8102e" },
  CTN: { name: "Croatia Airlines", iata: "OU", brand: "#00539b", second: "#c8102e" },
  ASL: { name: "Air Serbia", iata: "JU", brand: "#0c4076", second: "#c6363c" },
  AMC: { name: "Air Malta", iata: "KM", brand: "#c8102e", second: "#5c5c5c" },
  KMM: { name: "KM Malta Airlines", iata: "KM", brand: "#c8102e", second: "#5c5c5c" },
  CYP: { name: "Cyprus Airways", iata: "CY", brand: "#ef8200", second: "#003a70" },
  OAL: { name: "Olympic Air", iata: "OA", brand: "#003a70", second: "#d4a017" },
  SKX: { name: "Skyexpress", iata: "GQ", brand: "#00539b", second: "#78be20" },
  AUI: { name: "Ukraine International", iata: "PS", brand: "#003a70", second: "#ffcc00" },
  BEE: { name: "Flybe", iata: "BE", brand: "#5b2a86", second: "#d6006d" },
  GWI: { name: "Germanwings", iata: "4U", brand: "#a5004a", second: "#ffad00" },
  MON: { name: "Monarch", iata: "ZB", brand: "#f7a600", second: "#1a1a1a" },
  SVR: { name: "Ural Airlines", iata: "U6", brand: "#c8102e", second: "#00539b" },
  SBI: { name: "S7 Airlines", iata: "S7", brand: "#a6ce39", second: "#3a3a3a" },
  PBD: { name: "Pobeda", iata: "DP", brand: "#00539b", second: "#c8102e" },
  // Americas
  ENY: { name: "Envoy", iata: "MQ", brand: "#0078d2", second: "#c30019" },
  RPA: { name: "Republic Airways", iata: "YX", brand: "#003a70", second: "#c8102e" },
  SKW: { name: "SkyWest", iata: "OO", brand: "#002f6c", second: "#0067b1" },
  EDV: { name: "Endeavor Air", iata: "9E", brand: "#003a70", second: "#c8102e" },
  JIA: { name: "PSA Airlines", iata: "OH", brand: "#0078d2", second: "#c30019" },
  PDT: { name: "Piedmont Airlines", iata: "PT", brand: "#0078d2", second: "#c30019" },
  ASH: { name: "Mesa Airlines", iata: "YV", brand: "#002244", second: "#0060a9" },
  QXE: { name: "Horizon Air", iata: "QX", brand: "#01426a", second: "#48a9c5" },
  AAY: { name: "Allegiant", iata: "G4", brand: "#003a70", second: "#f7a800" },
  SCX: { name: "Sun Country", iata: "SY", brand: "#ef7d00", second: "#1a1a1a" },
  MXY: { name: "Breeze Airways", iata: "MX", brand: "#00a3e0", second: "#002855" },
  VXP: { name: "Avelo", iata: "XP", brand: "#5b2a86", second: "#f7a800" },
  JZA: { name: "Jazz", iata: "QK", brand: "#d22630", second: "#1a1a1a", neutral: true },
  ROU: { name: "Air Canada Rouge", iata: "RV", brand: "#d22630", second: "#1a1a1a" },
  POE: { name: "Porter", iata: "PD", brand: "#002855", second: "#c8a45d" },
  TSC: { name: "Air Transat", iata: "TS", brand: "#003a70", second: "#00a3e0" },
  FLE: { name: "Flair Airlines", iata: "F8", brand: "#a6ce39", second: "#3a3a3a" },
  WSW: { name: "Swoop", iata: "WO", brand: "#d6006d", second: "#f7a800" },
  FDX: { name: "FedEx Express", iata: "FX", brand: "#4d148c", second: "#ff6600" },
  UPS: { name: "UPS Airlines", iata: "5X", brand: "#351c15", second: "#ffb500" },
  GTI: { name: "Atlas Air", iata: "5Y", brand: "#003a70", second: "#c8102e" },
  ABX: { name: "ABX Air", iata: "GB", brand: "#003a70", second: "#c8102e" },
  CKS: { name: "Kalitta Air", iata: "K4", brand: "#c8102e", second: "#1a1a1a" },
  CLX: { name: "Cargolux", iata: "CV", brand: "#00539b", second: "#c8102e" },
  CAO: { name: "Air China Cargo", iata: "CA", brand: "#c8102e", second: "#4d4d4d" },
  BOX: { name: "AeroLogic", iata: "3S", brand: "#ffcc00", second: "#d40511", neutral: true },
  GEC: { name: "Lufthansa Cargo", iata: "LH", brand: "#05164d", second: "#ffad00" },
  VIV: { name: "Viva Aerobus", iata: "VB", brand: "#00a651", second: "#3a3a3a" },
  SLI: { name: "Aeroméxico Connect", iata: "5D", brand: "#0b2343", second: "#e60f27" },
  ARE: { name: "Avianca (ARE)", iata: "AV", brand: "#da291c", second: "#4d4d4d" },
  LPE: { name: "LATAM Perú", iata: "LP", brand: "#1b0088", second: "#ed1650" },
  SKU: { name: "Sky Airline", iata: "H2", brand: "#2b2a6b", second: "#ff4b55" },
  JAT: { name: "JetSMART", iata: "JA", brand: "#1b2a5b", second: "#e2001a" },
  BOV: { name: "Boliviana de Aviación", iata: "OB", brand: "#00539b", second: "#c8102e" },
  LAP: { name: "Paranair", iata: "ZP", brand: "#003a70", second: "#c8102e" },
  FBZ: { name: "Flybondi", iata: "FO", brand: "#f7a600", second: "#3a3a3a" },
  BWA: { name: "Caribbean Airlines", iata: "BW", brand: "#00539b", second: "#78be20" },
  BHS: { name: "Bahamasair", iata: "UP", brand: "#00a3e0", second: "#ffd100" },
  CUB: { name: "Cubana", iata: "CU", brand: "#002a8f", second: "#cf142b" },
  IBB: { name: "Binter", iata: "NT", brand: "#78be20", second: "#003a70" },
  // Africa
  SFR: { name: "Safair", iata: "FA", brand: "#00539b", second: "#f7a600" },
  LNK: { name: "Airlink", iata: "4Z", brand: "#c8102e", second: "#003a70" },
  CAW: { name: "Comair", iata: "MN", brand: "#003a70", second: "#c8102e" },
  DAH: { name: "Air Algérie", iata: "AH", brand: "#c8102e", second: "#007a3d" },
  TAR: { name: "Tunisair", iata: "TU", brand: "#c8102e", second: "#5c5c5c" },
  LAA: { name: "Libyan Airlines", iata: "LN", brand: "#007a3d", second: "#c8102e" },
  NSO: { name: "Nile Air", iata: "NP", brand: "#003a70", second: "#c8a45d" },
  ATC: { name: "Air Tanzania", iata: "TC", brand: "#00539b", second: "#78be20" },
  UGD: { name: "Uganda Airlines", iata: "UR", brand: "#1a1a1a", second: "#fcdc04", neutral: true },
  ANO: { name: "Air Namibia", iata: "SW", brand: "#003a70", second: "#c8102e" },
  DTA: { name: "TAAG Angola", iata: "DT", brand: "#c8102e", second: "#1a1a1a" },
  ASK: { name: "ASKY Airlines", iata: "KP", brand: "#003a70", second: "#78be20" },
  APK: { name: "Air Peace", iata: "P4", brand: "#003a70", second: "#c8102e" },
  ARA: { name: "Arik Air", iata: "W3", brand: "#c8102e", second: "#003a70" },
  MAU: { name: "Air Mauritius", iata: "MK", brand: "#c8102e", second: "#00a19a" },
  SEY: { name: "Air Seychelles", iata: "HM", brand: "#c8102e", second: "#00539b" },
  MDG: { name: "Madagascar Airlines", iata: "MD", brand: "#c8102e", second: "#007a3d" },
};
for (const [k, v] of Object.entries(MORE)) if (v.name && v.iata && !AIRLINES[k]) AIRLINES[k] = v;
for (const [k, v] of Object.entries(EXTRA)) if (v.name && v.iata && !AIRLINES[k]) AIRLINES[k] = v;

/** The airline in a VATSIM callsign (QTR123, IGO6E45 → QTR, IGO), if it's one VBuddy knows. */
export function airlineOf(callsign: string | null | undefined): (Airline & { icao: string }) | null {
  const m = /^([A-Z]{3})[0-9]/.exec((callsign ?? "").toUpperCase().trim());
  if (!m) return null;
  const a = AIRLINES[m[1]!];
  return a ? { ...a, icao: m[1]! } : null;
}

const norm = (s: string) => s.toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Z0-9]+/g, " ").trim();
const GENERIC = /\b(AIRWAYS|AIRLINES|AIRLINE|AIR LINES|AVIATION|INTERNATIONAL|CARGO|GROUP)\b/g;

let byName: Map<string, string> | null = null;
let titleNames: Array<[string, string]> | null = null;
/** Every name an airline goes by: its code, its name (with and without "Airways"), and how ATC says it. */
function names() {
  if (byName && titleNames) return { byName, titleNames };
  byName = new Map();
  const add = (k: string, icao: string) => {
    const n = norm(k);
    if (n && !byName!.has(n)) byName!.set(n, icao);
  };
  for (const [icao, a] of Object.entries(AIRLINES)) {
    add(icao, icao);
    add(a.name.replace(/\(.*?\)/g, ""), icao);
    add(norm(a.name.replace(/\(.*?\)/g, "")).replace(GENERIC, ""), icao);
  }
  for (const [icao, t] of Object.entries(TELEPHONY)) if (AIRLINES[icao]) add(t, icao);
  // Names long enough to look for inside an aircraft title ("FenixA320 Qatar Airways A7-AHX"), longest first.
  titleNames = [...byName.entries()].filter(([n]) => n.length >= 5 && !/^[A-Z]{3}$/.test(n)).sort((a, b) => b[0].length - a[0].length);
  return { byName, titleNames };
}

/**
 * The airline the sim says you are, when there is no VATSIM callsign or SimBrief plan: the livery's ATC AIRLINE
 * ("IndiGo", "Qatar", "Speedbird", "QTR"), else an airline named in the aircraft's title. With the sim's flight
 * number it makes a callsign (IGO612) so the rest of the app treats it like any other.
 */
export function airlineFromSim(atcAirline: string | null | undefined, flightNumber: string | null | undefined, title?: string | null): { icao: string; airline: Airline; callsign: string | null } | null {
  const { byName, titleNames } = names();
  const fno = (flightNumber ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 5);
  const make = (icao: string) => ({ icao, airline: AIRLINES[icao]!, callsign: fno && /^[0-9]/.test(fno) ? `${icao}${fno}` : null });
  const raw = norm(atcAirline ?? "");
  if (raw) {
    const hit = byName.get(raw) ?? byName.get(raw.replace(GENERIC, "").replace(/\s+/g, " ").trim()) ?? byName.get(raw.replace(/\s+/g, ""));
    if (hit) return make(hit);
  }
  const t = ` ${norm(title ?? "")} `;
  if (t.trim()) for (const [n, icao] of titleNames) if (t.includes(` ${n} `)) return make(icao);
  return null;
}
